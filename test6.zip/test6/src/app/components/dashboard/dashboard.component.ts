import { Component, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CourseService } from '../../services/course.service';
import { User } from '../../models/user.model';
import { Course, UserEnrollment, DashboardStats } from '../../models/course.model';
import { SearchBarComponent } from '../search-bar/search-bar.component';
import { CourseCarouselComponent } from '../course-carousel/course-carousel.component';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, SearchBarComponent, CourseCarouselComponent],
  template: `
    <div class="dashboard-container">
      <header class="dashboard-header">
        <div class="header-content">
          <h1 class="product-name">Product Name</h1>
          <app-search-bar 
            (courseSelected)="onCourseSelected($event)"
            (searchResults)="onSearchResults($event)"
          ></app-search-bar>
          <div class="header-actions">
            <div class="notification-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              <span class="notification-badge">1</span>
            </div>
            <div class="user-menu" *ngIf="currentUser">
              <img [src]="currentUser.avatarUrl" [alt]="currentUser.fullName" class="user-avatar" (click)="toggleUserMenu()" />
              <div class="user-dropdown" [class.show]="showUserMenu">
                <div class="user-info">
                  <div class="user-avatar-large">
                    <img [src]="currentUser.avatarUrl" [alt]="currentUser.fullName" class="dropdown-avatar" />
                  </div>
                  <div class="user-details">
                    <p class="user-name">{{ currentUser.fullName }}</p>
                    <p class="user-role">{{ currentUser.track || currentUser.role }}</p>
                  </div>
                </div>
                <hr>
                <button class="dropdown-item" (click)="navigateToProfile()">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                  </svg>
                  My Profile
                </button>
                <button class="dropdown-item" (click)="navigateToAdminConsole()" *ngIf="currentUser.role === 'Admin'">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="9" y1="9" x2="9" y2="15"></line>
                    <line x1="15" y1="9" x2="15" y2="15"></line>
                  </svg>
                  Admin Console
                </button>
                <button class="dropdown-item" (click)="navigateToMyCourses()">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                  </svg>
                  My Courses
                </button>
                <button class="dropdown-item" (click)="navigateToBlog()">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  </svg>
                  Blog
                </button>
                <hr>
                <button class="dropdown-item logout" (click)="logout()">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16,17 21,12 16,7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                  </svg>
                  Log Out
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main class="dashboard-main">
        <!-- Enhanced Statistics Section -->
        <div class="stats-section">
          <div class="stats-grid">
            <div class="stat-card goals">
              <div class="stat-content">
                <h3 class="stat-title">My Goals</h3>
                <div class="stat-value">{{ dashboardStats.myGoals }}</div>
                <a href="#" class="stat-link">View All</a>
              </div>
              <div class="stat-visual">
                <div class="chart-container">
                  <img src="assets/images/goal-chart.png" alt="Goal Chart" width="80" height="80" />
                </div>
              </div>
            </div>

            <div class="stat-card courses" >
              <div class="stat-content">
                <h3 class="stat-title">Enrolled Courses</h3>
                <div class="stat-value">{{ dashboardStats.enrolledCourses }}</div>
                <a href="#" class="stat-link">View All</a>
              </div>
              <div class="stat-visual">
                <div class="progress-rings">
                  <img src="assets/images/course-chart.png" alt="Course Chart" width="80" height="80" />
                </div>
              </div>
            </div>

            <div class="stat-card certificates">
              <div class="stat-content">
                <h3 class="stat-title">Certificates Earned</h3>
                <div class="stat-value">{{ dashboardStats.certificatesEarned }}</div>
                <a href="#" class="stat-link">Download</a>
              </div>
              <div class="stat-visual">
                <div class="certificate-icon">
                  <img src="assets/images/certificate-icon.png" alt="Certificate Icon" width="80" height="80" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Course Carousels Section -->
        <div class="courses-section">

          <app-course-carousel
            title="Last Viewed Courses"
            [courses]="lastViewedCourses"
            [enrollments]="userEnrollments"
          ></app-course-carousel>

          <app-course-carousel
            title="Newly Launched"
            [courses]="newlyLaunchedCourses"
            [enrollments]="userEnrollments"
          ></app-course-carousel>
        </div>
      </main>
    </div>
  `,
  styles: [`
    .dashboard-container {
      min-height: 100vh;
      background: #f8fafc;
    }

    .dashboard-header {
      background: white;
      border-bottom: 1px solid #e5e7eb;
      padding: 0 24px;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 64px;
      max-width: 1200px;
      margin: 0 auto;
    }

    .product-name {
      font-size: 20px;
      font-weight: 600;
      color: #111827;
      margin: 0;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .notification-icon {
      position: relative;
      cursor: pointer;
      color: #6b7280;
    }

    .notification-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      background: #ef4444;
      color: white;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 10px;
      min-width: 16px;
      text-align: center;
    }

    .user-menu {
      position: relative;
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      cursor: pointer;
      border: 2px solid #e5e7eb;
    }

    .user-dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 12px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
      padding: 0;
      min-width: 280px;
      z-index: 1000;
      display: none;
      margin-top: 8px;
      overflow: hidden;
    }

    .user-dropdown.show {
      display: block;
    }

    .user-info {
      padding: 20px 16px;
      background: #98bcb7;
      color: white;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .user-avatar-large {
      flex-shrink: 0;
    }

    .dropdown-avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      border: 2px solid rgba(255, 255, 255, 0.2);
    }

    .user-details {
      flex: 1;
      min-width: 0;
    }

    .user-name {
      font-weight: 600;
      color: white;
      margin: 0 0 4px 0;
      font-size: 16px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .user-role {
      font-size: 13px;
      color: rgba(255, 255, 255, 0.8);
      margin: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .user-dropdown hr {
      margin: 0;
      border: none;
      border-top: 1px solid #f3f4f6;
    }

    .dropdown-item {
      width: 100%;
      background: none;
      border: none;
      padding: 12px 16px;
      text-align: left;
      cursor: pointer;
      transition: background-color 0.2s;
      color: #374151;
      font-size: 14px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .dropdown-item:hover {
      background: #f9fafb;
    }

    .dropdown-item svg {
      flex-shrink: 0;
      color: #6b7280;
    }

    .dropdown-item.logout {
      color: #ef4444;
    }

    .dropdown-item.logout svg {
      color: #ef4444;
    }

    .dashboard-main {
      max-width: 1200px;
      margin: 0 auto;
      padding: 24px;
      background: #f8fafc;
    }

    .stats-section {
      margin-bottom: 48px;
    }

    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 24px;
    }

    .stat-card {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      border-radius: 20px;
      padding: 24px;
      color: black;
      position: relative;
      overflow: hidden;
      display: flex;
      justify-content: space-between;
      align-items: center;
      min-height: 140px;
    }

    .stat-card.goals {
      background: #dbe3cd;
    }

    .stat-card.courses {
      background: #cde1d8;
    }

    .stat-card.certificates {
      background: #c0d8e3;
    }

    .stat-content {
      flex: 1;
    }

    .stat-title {
      font-size: 14px;
      font-weight: 100;
      margin: 0 0 8px 0;
      opacity: 0.9;
    }

    .stat-value {
      font-size: 48px;
      font-weight: 100;
      margin: 8px 0;
      line-height: 1;
    }

    .stat-link {
      color: #20a4d4ff;
      text-decoration: none;
      font-size: 14px;
      font-weight: 500;
      opacity: 0.9;
    }

    .stat-visual {
      flex-shrink: 0;
      margin-left: 16px;
    }

    .chart-container {
      position: relative;
    }

    .progress-rings {
      position: relative;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .progress-text {
      position: absolute;
      font-size: 12px;
      font-weight: 600;
      color: white;
    }

    .certificate-icon {
      opacity: 0.8;
    }

    .courses-section {
      display: flex;
      flex-direction: column;
      gap: 32px;
    }

    @media (max-width: 768px) {
      .header-content {
        flex-direction: column;
        height: auto;
        padding: 16px 0;
        gap: 16px;
      }

      .stats-grid {
        grid-template-columns: 1fr;
      }

      .dashboard-main {
        padding: 16px;
      }

      .welcome-title {
        font-size: 24px;
      }
    }
  `]
})
export class DashboardComponent implements OnInit {
  currentUser: User | null = null;
  showUserMenu = false;
  dashboardStats: DashboardStats = {
    myGoals: 0,
    enrolledCourses: 0,
    certificatesEarned: 0
  };
  
  lastViewedCourses: Course[] = [];
  newlyLaunchedCourses: Course[] = [];
  userEnrollments: UserEnrollment[] = [];

  constructor(
    private authService: AuthService,
    private courseService: CourseService,
    private router: Router
  ) {}

  ngOnInit() {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadDashboardData();
      }
    });
  }

  loadDashboardData() {
    if (!this.currentUser) return;

    forkJoin({
      lastViewed: this.courseService.getLastViewedCourses(this.currentUser.id.toString()),
      newlyLaunched: this.courseService.getNewlyLaunchedCourses(),
      enrollments: this.courseService.getUserEnrollments(this.currentUser.id.toString())
    }).subscribe({
      next: (data) => {
        console.log('Dashboard data loaded:', data);
        this.lastViewedCourses = data.lastViewed;
        this.newlyLaunchedCourses = data.newlyLaunched;
        this.userEnrollments = data.enrollments;
        
        console.log('Last viewed courses:', this.lastViewedCourses);
        console.log('Newly launched courses:', this.newlyLaunchedCourses);
        console.log('User enrollments:', this.userEnrollments);
        
        this.dashboardStats = {
          myGoals: 12, // This would come from a goals service
          enrolledCourses: data.enrollments.length,
          certificatesEarned: data.enrollments.filter(e => e.progressPercent === 100).length
        };
      },
      error: (error) => {
        console.error('Error loading dashboard data:', error);
      }
    });
  }

  onCourseSelected(course: Course) {
    // Navigate to course detail or handle course selection
    console.log('Course selected:', course);
  }

  onSearchResults(courses: Course[]) {
    // Handle search results - could navigate to a search results page
    console.log('Search results:', courses);
  }

  getCompletionPercentage(): number {
    if (this.userEnrollments.length === 0) return 0;
    const totalProgress = this.userEnrollments.reduce((sum, enrollment) => sum + enrollment.progressPercent, 0);
    return Math.round(totalProgress / this.userEnrollments.length);
  }

  getFirstName(): string {
    if (!this.currentUser?.fullName) return 'User';
    return this.currentUser.fullName.split(' ')[0];
  }

  toggleUserMenu() {
    this.showUserMenu = !this.showUserMenu;
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    const userMenu = target.closest('.user-menu');
    
    if (!userMenu && this.showUserMenu) {
      this.showUserMenu = false;
    }
  }

  navigateToProfile() {
    this.showUserMenu = false;
    // Navigate to profile page - implement when profile component is created
    console.log('Navigate to My Profile');
    // this.router.navigate(['/profile']);
  }

  navigateToAdminConsole() {
    this.showUserMenu = false;
    // Navigate to admin console - implement when admin component is created
    console.log('Navigate to Admin Console');
    // this.router.navigate(['/admin']);
  }

  navigateToMyCourses() {
    this.showUserMenu = false;
    // Navigate to my courses page - implement when courses component is created
    console.log('Navigate to My Courses');
    // this.router.navigate(['/my-courses']);
  }

  navigateToBlog() {
    this.showUserMenu = false;
    // Navigate to blog page - implement when blog component is created
    console.log('Navigate to Blog');
    // this.router.navigate(['/blog']);
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
