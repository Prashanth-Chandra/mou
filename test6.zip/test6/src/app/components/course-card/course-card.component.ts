import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Course, UserEnrollment } from '../../models/course.model';

@Component({
  selector: 'app-course-card',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="course-card">
      <div class="course-thumbnail">
        <img [src]="course.thumbnailUrl" [alt]="course.title" class="course-image" />
        <div class="progress-overlay" *ngIf="enrollment">
          <span class="progress-badge">{{ enrollment.progressPercent }}% Complete</span>
        </div>
      </div>
      
      <div class="course-content">
        <h3 class="course-title">{{ course.title }}</h3>
        
        <div class="provider-info">
          <img [src]="course.provider.logoUrl" [alt]="course.provider.name" class="provider-logo" />
          <span class="provider-name">{{ course.provider.name }}</span>
        </div>
        
        <div class="course-rating">
          <div class="rating-section">
            <span class="rating-number">{{ course.rating }}</span>
            <div class="stars">
                <svg class="star" [ngClass]="{
                    'green-star': course.rating >= 4,
                    'yellow-star': course.rating >= 2 && course.rating < 4,
                    'red-star': course.rating < 2
                }"
                width="12" height="12" viewBox="0 0 24 24">
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                </svg>
            </div>
            <span class="review-text">({{ formatNumber(course.reviewCount) }} reviews | {{ formatNumber(course.enrollmentCount) }} Enrolled)</span>
          </div>
        </div>
        
        <div class="course-meta">
          <span class="difficulty-badge" [class]="'difficulty-' + course.difficulty.toLowerCase()">
            {{ course.difficulty }}
          </span>
          <span class="duration">{{ course.durationText }}</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .course-card {
      background: white;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: all 0.3s ease;
      cursor: pointer;
      width: 280px;
      flex-shrink: 0;
    }

    .course-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    }

    .course-thumbnail {
      position: relative;
      width: 100%;
      height: 160px;
      overflow: hidden;
    }

    .course-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .progress-overlay {
      position: absolute;
      top: 12px;
      right: 12px;
    }

    .progress-badge {
      background: rgba(0, 0, 0, 0.8);
      color: white;
      padding: 6px 12px;
      border-radius: 20px;
      font-size: 12px;
      font-weight: 600;
    }

    .course-content {
      padding: 16px;
    }

    .course-title {
      font-size: 16px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 12px 0;
      line-height: 1.4;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .provider-info {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 12px;
    }

    .provider-logo {
      width: 16px;
      height: 16px;
      border-radius: 2px;
    }

    .provider-name {
      font-size: 12px;
      color: #0066cc;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .course-rating {
      margin-bottom: 12px;
    }

    .rating-section {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }

    .rating-number {
      font-size: 14px;
      font-weight: 600;
      color: #111827;
    }

    .stars {
      display: flex;
      gap: 1px;
    }

    .star {
      fill: #d1d5db;
      stroke: none;
    }

    .green-star {
        fill: green;
    }

    .yellow-star {
        fill: gold;
    }

    .red-star {
        fill: red;
    }


    .star.filled {
      fill: #fbbf24;
    }

    .review-text {
      font-size: 12px;
      color: #6b7280;
    }

    .course-meta {
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 12px;
      color: #6b7280;
    }

    .difficulty-badge {
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: 600;
      text-transform: capitalize;
    }

    .difficulty-beginner {
      background: #dcfce7;
      color: #16a34a;
    }

    .difficulty-intermediate {
      background: #fef3c7;
      color: #d97706;
    }

    .difficulty-advanced {
      background: #fee2e2;
      color: #dc2626;
    }

    .duration {
      font-weight: 500;
    }

    @media (max-width: 768px) {
      .course-card {
        width: 100%;
        max-width: 320px;
      }
    }
  `]
})
export class CourseCardComponent {
  @Input() course!: Course;
  @Input() enrollment?: UserEnrollment;

  circumference = 2 * Math.PI * 20;

  get strokeDashoffset(): number {
    if (!this.enrollment) return this.circumference;
    const progress = this.enrollment.progressPercent / 100;
    return this.circumference - (progress * this.circumference);
  }

  getStarsArray(): number[] {
    return Array(5).fill(0).map((_, i) => i);
  }

  formatNumber(num: number): string {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  get Math() {
    return Math;
  }
}
