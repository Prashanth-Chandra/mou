import { Component, Input, ViewChild, ElementRef, AfterViewInit, OnChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseCardComponent } from '../course-card/course-card.component';
import { Course, UserEnrollment } from '../../models/course.model';

@Component({
  selector: 'app-course-carousel',
  standalone: true,
  imports: [CommonModule, CourseCardComponent],
  template: `
    <div class="carousel-container">
      <div class="carousel-header">
        <h2 class="carousel-title">{{ title }}</h2>
        <div class="carousel-controls">
          <button 
            class="carousel-btn prev" 
            [disabled]="!canScrollLeft"
            (click)="scrollLeft()"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <polyline points="15,18 9,12 15,6"></polyline>
            </svg>
          </button>
          <button 
            class="carousel-btn next" 
            [disabled]="!canScrollRight"
            (click)="scrollRight()"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <polyline points="9,18 15,12 9,6"></polyline>
            </svg>
          </button>
        </div>
      </div>
      
      <div class="carousel-wrapper">
        <div 
          #carouselTrack
          class="carousel-track"
          (scroll)="onScroll()"
        >
          <app-course-card
            *ngFor="let course of courses"
            [course]="course"
            [enrollment]="getEnrollmentForCourse(course.id)"
            class="carousel-item"
          ></app-course-card>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .carousel-container {
      margin-bottom: 32px;
    }

    .carousel-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
    }

    .carousel-title {
      font-size: 20px;
      font-weight: 600;
      color: #111827;
      margin: 0;
    }

    .carousel-controls {
      display: flex;
      gap: 8px;
    }

    .carousel-btn {
      width: 40px;
      height: 40px;
      border: 1px solid #e5e7eb;
      background: white;
      border-radius: 8px;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: all 0.2s ease;
      color: #6b7280;
    }

    .carousel-btn:hover:not(:disabled) {
      background: #f9fafb;
      border-color: #d1d5db;
      color: #374151;
    }

    .carousel-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .carousel-wrapper {
      position: relative;
      overflow: hidden;
    }

    .carousel-track {
      display: flex;
      gap: 16px;
      overflow-x: auto;
      scroll-behavior: smooth;
      padding-bottom: 8px;
      scrollbar-width: none;
      -ms-overflow-style: none;
    }

    .carousel-track::-webkit-scrollbar {
      display: none;
    }

    .carousel-item {
      flex-shrink: 0;
    }

    @media (max-width: 768px) {
      .carousel-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
      }

      .carousel-controls {
        align-self: flex-end;
      }

      .carousel-title {
        font-size: 18px;
      }
    }
  `]
})
export class CourseCarouselComponent implements AfterViewInit, OnChanges {
  @Input() title!: string;
  @Input() courses: Course[] = [];
  @Input() enrollments: UserEnrollment[] = [];
  @ViewChild('carouselTrack') carouselTrack!: ElementRef;

  canScrollLeft = false;
  canScrollRight = true;

  ngOnChanges() {
    console.log(`${this.title} - Courses received:`, this.courses);
    console.log(`${this.title} - Enrollments received:`, this.enrollments);
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.updateScrollButtons();
    });
  }

  scrollLeft() {
    const track = this.carouselTrack.nativeElement;
    const scrollAmount = 320; // Card width + gap
    track.scrollLeft -= scrollAmount;
  }

  scrollRight() {
    const track = this.carouselTrack.nativeElement;
    const scrollAmount = 320; // Card width + gap
    track.scrollLeft += scrollAmount;
  }

  onScroll() {
    this.updateScrollButtons();
  }

  private updateScrollButtons() {
    const track = this.carouselTrack.nativeElement;
    this.canScrollLeft = track.scrollLeft > 0;
    this.canScrollRight = track.scrollLeft < (track.scrollWidth - track.clientWidth - 1);
  }

  getEnrollmentForCourse(courseId: number): UserEnrollment | undefined {
    return this.enrollments.find(enrollment => enrollment.courseId === courseId);
  }
}
