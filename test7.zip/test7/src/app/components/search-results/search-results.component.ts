import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CourseService } from '../../services/course.service';
import { Course } from '../../models/course.model';

@Component({
  selector: 'app-search-results',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="search-results-container">
      <header class="search-header">
        <div class="header-content">
          <h1 class="product-name">Product Name</h1>
          <div class="search-wrapper">
            <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.35-4.35"></path>
            </svg>
            <input 
              type="text" 
              [(ngModel)]="searchQuery"
              (keydown.enter)="performSearch()"
              class="search-input"
              placeholder="Search courses..."
            />
            <button 
              class="clear-button" 
              *ngIf="searchQuery" 
              (click)="clearSearch()"
              type="button"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
          <div class="header-actions">
            <div class="notification-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              <span class="notification-badge">1</span>
            </div>
            <div class="user-avatar" (click)="goToDashboard()">
              <img src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-1.2.1&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80" alt="User" />
            </div>
          </div>
        </div>
      </header>

      <div class="search-content">
        <div class="filters-sidebar">
          <h3 class="filter-title">Filter</h3>
          
          <!-- Duration Filter -->
          <div class="filter-section">
            <h4 class="filter-label">Duration</h4>
            <div class="filter-options">
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.duration.all" (change)="onDurationFilterChange('all')">
                <span class="checkmark"></span>
                All <span class="count">({{ totalCourses }})</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.duration.lessThanWeek" (change)="onDurationFilterChange('lessThanWeek')">
                <span class="checkmark"></span>
                &lt;1 week <span class="count">(10)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.duration.oneToFourWeeks" (change)="onDurationFilterChange('oneToFourWeeks')">
                <span class="checkmark"></span>
                1 - 4 weeks <span class="count">(20)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.duration.oneToThreeMonths" (change)="onDurationFilterChange('oneToThreeMonths')">
                <span class="checkmark"></span>
                1 - 3 Months <span class="count">(30)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.duration.threeToSixMonths" (change)="onDurationFilterChange('threeToSixMonths')">
                <span class="checkmark"></span>
                3 - 6 Months <span class="count">(50)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.duration.sixToTwelveMonths" (change)="onDurationFilterChange('sixToTwelveMonths')">
                <span class="checkmark"></span>
                6 - 12 Months <span class="count">(50)</span>
              </label>
            </div>
          </div>

          <!-- Rating Filter -->
          <div class="filter-section">
            <h4 class="filter-label">Rating</h4>
            <div class="filter-options">
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.rating.all" (change)="onRatingFilterChange('all')">
                <span class="checkmark"></span>
                All <span class="count">({{ totalCourses }})</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.rating.fourFiveAndUp" (change)="onRatingFilterChange('fourFiveAndUp')">
                <span class="checkmark"></span>
                <div class="stars">
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star half">★</span>
                </div>
                4.5 & up <span class="count">(20)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.rating.fourAndUp" (change)="onRatingFilterChange('fourAndUp')">
                <span class="checkmark"></span>
                <div class="stars">
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star">★</span>
                </div>
                4 & up <span class="count">(30)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.rating.threeFiveAndUp" (change)="onRatingFilterChange('threeFiveAndUp')">
                <span class="checkmark"></span>
                <div class="stars">
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star half">★</span>
                  <span class="star">★</span>
                </div>
                3.5 & up <span class="count">(20)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.rating.threeAndUp" (change)="onRatingFilterChange('threeAndUp')">
                <span class="checkmark"></span>
                <div class="stars">
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star filled">★</span>
                  <span class="star">★</span>
                  <span class="star">★</span>
                </div>
                3 & up <span class="count">(50)</span>
              </label>
            </div>
          </div>

          <!-- Published Date Filter -->
          <div class="filter-section">
            <h4 class="filter-label">Published Date</h4>
            <div class="filter-options">
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.publishedDate.all" (change)="onPublishedDateFilterChange('all')">
                <span class="checkmark"></span>
                All <span class="count">({{ totalCourses }})</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.publishedDate.thisWeek" (change)="onPublishedDateFilterChange('thisWeek')">
                <span class="checkmark"></span>
                This week <span class="count">(10)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.publishedDate.thisMonth" (change)="onPublishedDateFilterChange('thisMonth')">
                <span class="checkmark"></span>
                This Month <span class="count">(20)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.publishedDate.lastSixMonths" (change)="onPublishedDateFilterChange('lastSixMonths')">
                <span class="checkmark"></span>
                Last 6 Months <span class="count">(30)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.publishedDate.thisYear" (change)="onPublishedDateFilterChange('thisYear')">
                <span class="checkmark"></span>
                This year <span class="count">(50)</span>
              </label>
            </div>
          </div>

          <!-- Course Level Filter -->
          <div class="filter-section">
            <h4 class="filter-label">Course Level</h4>
            <div class="filter-options">
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.courseLevel.all" (change)="onCourseLevelFilterChange('all')">
                <span class="checkmark"></span>
                All <span class="count">({{ totalCourses }})</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.courseLevel.beginner" (change)="onCourseLevelFilterChange('beginner')">
                <span class="checkmark"></span>
                Beginner <span class="count">(60)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.courseLevel.intermediate" (change)="onCourseLevelFilterChange('intermediate')">
                <span class="checkmark"></span>
                Intermediate <span class="count">(40)</span>
              </label>
              <label class="filter-option">
                <input type="checkbox" [(ngModel)]="filters.courseLevel.advanced" (change)="onCourseLevelFilterChange('advanced')">
                <span class="checkmark"></span>
                Advanced <span class="count">(20)</span>
              </label>
            </div>
          </div>
        </div>

        <div class="results-content">
          <div class="results-header">
            <h2 class="results-title">{{ filteredCourses.length }} Results for "{{ originalQuery }}"</h2>
            <div class="sort-controls">
              <label for="sort-select">Sort:</label>
              <select id="sort-select" [(ngModel)]="sortBy" (change)="applySorting()">
                <option value="latest">Latest</option>
                <option value="rating">Highest Rated</option>
                <option value="alphabetical">A-Z</option>
                <option value="duration">Duration</option>
              </select>
            </div>
          </div>

          <div class="results-grid" *ngIf="filteredCourses.length > 0">
            <div *ngFor="let course of paginatedCourses" class="course-result-item">
              <!-- Custom search result card -->
              <div class="search-course-card">
                <div class="course-thumbnail">
                  <img [src]="course.thumbnailUrl" [alt]="course.title" class="course-image" />
                </div>
                
                <div class="course-content">
                  <h3 class="course-title">{{ course.title }}</h3>
                  
                  <div class="skills-section" *ngIf="course.skills && course.skills.length > 0">
                    <span class="skills-label">Skills you'll gain:</span>
                    <span class="skills-text">{{ getSkillsText(course.skills) }}</span>
                  </div>
                  
                  <div class="course-rating">
                    <div class="rating-section">
                      <span class="rating-number">{{ course.rating }}</span>
                      <div class="stars">
                          <svg class="star filled" width="12" height="12" viewBox="0 0 24 24">
                              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                          </svg>
                      </div>
                      <span class="review-text">{{ formatNumber(course.reviewCount) }} reviews</span>
                    </div>
                  </div>
                  
                  <div class="course-meta">
                    <span class="difficulty-badge" [class]="'difficulty-' + course.difficulty.toLowerCase()">
                      {{ course.difficulty }}
                    </span>
                    <span class="separator">|</span>
                    <span class="duration">{{ course.durationText }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="no-results" *ngIf="filteredCourses.length === 0">
            <div class="no-results-icon">
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.35-4.35"></path>
              </svg>
            </div>
            <h3>No courses found</h3>
            <p>Try adjusting your search terms or filters</p>
          </div>

          <!-- Pagination would go here -->
        </div>
      </div>
    </div>
  `,
  styles: [`
    .search-results-container {
      min-height: 100vh;
      background: #f8fafc;
    }

    .search-header {
      background: white;
      border-bottom: 1px solid #e5e7eb;
      padding: 0 24px;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 64px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .product-name {
      font-size: 20px;
      font-weight: 600;
      color: #111827;
      margin: 0;
      cursor: pointer;
    }

    .search-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      background: white;
      border: 2px solid #e5e7eb;
      border-radius: 8px;
      padding: 0 12px;
      max-width: 600px;
      flex: 1;
      margin: 0 24px;
    }

    .search-icon {
      color: #9ca3af;
      margin-right: 8px;
    }

    .search-input {
      flex: 1;
      border: none;
      outline: none;
      padding: 12px 0;
      font-size: 14px;
      background: transparent;
    }

    .search-input::placeholder {
      color: #9ca3af;
    }

    .clear-button {
      background: none;
      border: none;
      padding: 4px;
      color: #9ca3af;
      cursor: pointer;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .clear-button:hover {
      color: #6b7280;
      background: #f3f4f6;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .notification-icon {
      position: relative;
      cursor: pointer;
      color: #6b7280;
    }

    .notification-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      background: #ef4444;
      color: white;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 10px;
      min-width: 16px;
      text-align: center;
    }

    .user-avatar {
      cursor: pointer;
    }

    .user-avatar img {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      border: 2px solid #e5e7eb;
    }

    .search-content {
      display: grid;
      grid-template-columns: 300px 1fr;
      gap: 24px;
      max-width: 1400px;
      margin: 0 auto;
      padding: 24px;
    }

    .filters-sidebar {
      background: white;
      border-radius: 12px;
      padding: 24px;
      height: fit-content;
      border: 1px solid #e5e7eb;
    }

    .filter-title {
      font-size: 18px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 24px 0;
    }

    .filter-section {
      margin-bottom: 32px;
    }

    .filter-label {
      font-size: 16px;
      font-weight: 600;
      color: #374151;
      margin: 0 0 16px 0;
    }

    .filter-options {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .filter-option {
      display: flex;
      align-items: center;
      gap: 12px;
      cursor: pointer;
      font-size: 14px;
      color: #374151;
    }

    .filter-option input[type="checkbox"] {
      width: 16px;
      height: 16px;
      accent-color: #3b82f6;
    }

    .count {
      color: #9ca3af;
      margin-left: auto;
    }

    .stars {
      display: flex;
      gap: 2px;
    }

    .star {
      color: #d1d5db;
      font-size: 12px;
    }

    .star.filled {
      color: #fbbf24;
    }

    .star.half {
      color: #fbbf24;
    }

    .results-content {
      background: white;
      border-radius: 12px;
      border: 1px solid #e5e7eb;
      overflow: hidden;
    }

    .results-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 24px 24px 16px 24px;
      border-bottom: 1px solid #f3f4f6;
    }

    .results-title {
      font-size: 18px;
      font-weight: 600;
      color: #111827;
      margin: 0;
    }

    .sort-controls {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 14px;
      color: #6b7280;
    }

    .sort-controls select {
      border: 1px solid #e5e7eb;
      border-radius: 6px;
      padding: 6px 12px;
      font-size: 14px;
      color: #374151;
      background: white;
    }

    .results-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
      gap: 24px;
      padding: 24px;
    }

    .course-result-item {
      border-radius: 12px;
      overflow: hidden;
      transition: transform 0.2s ease, box-shadow 0.2s ease;
    }

    .course-result-item:hover {
      transform: translateY(-2px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
    }

    .search-course-card {
      background: white;
      border-radius: 12px;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: all 0.3s ease;
      cursor: pointer;
      height: 100%;
      display: flex;
      flex-direction: column;
    }

    .search-course-card:hover {
      transform: translateY(-4px);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.15);
    }

    .search-course-card .course-thumbnail {
      position: relative;
      width: 100%;
      height: 160px;
      overflow: hidden;
    }

    .search-course-card .course-image {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .search-course-card .course-content {
      padding: 16px;
      flex: 1;
      display: flex;
      flex-direction: column;
    }

    .search-course-card .course-title {
      font-size: 16px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 12px 0;
      line-height: 1.4;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    .search-course-card .skills-section {
      margin-bottom: 12px;
      flex: 1;
    }

    .search-course-card .skills-label {
      font-size: 12px;
      color: #6b7280;
      font-weight: 500;
      display: block;
    }

    .search-course-card .skills-text {
      font-size: 12px;
      color: #9ca3af;
      display: block;
      margin-top: 2px;
      line-height: 1.4;
    }

    .search-course-card .course-rating {
      margin-bottom: 12px;
      margin-top: auto;
    }

    .search-course-card .rating-section {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }

    .search-course-card .rating-number {
      font-size: 14px;
      font-weight: 600;
      color: #111827;
    }

    .search-course-card .stars {
      display: flex;
      gap: 1px;
    }

    .search-course-card .star {
      fill: #fbbf24;
      stroke: none;
    }

    .search-course-card .review-text {
      font-size: 12px;
      color: #6b7280;
    }

    .search-course-card .course-meta {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 12px;
      color: #6b7280;
    }

    .search-course-card .separator {
      color: #d1d5db;
      margin: 0 4px;
    }

    .search-course-card .difficulty-badge {
      padding: 2px 8px;
      border-radius: 12px;
      font-size: 11px;
      font-weight: 600;
      text-transform: capitalize;
    }

    .search-course-card .difficulty-beginner {
      background: #dcfce7;
      color: #16a34a;
    }

    .search-course-card .difficulty-intermediate {
      background: #fef3c7;
      color: #d97706;
    }

    .search-course-card .difficulty-advanced {
      background: #fee2e2;
      color: #dc2626;
    }

    .search-course-card .duration {
      font-weight: 500;
    }

    .no-results {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 64px 24px;
      text-align: center;
      color: #6b7280;
    }

    .no-results-icon {
      margin-bottom: 16px;
      opacity: 0.5;
    }

    .no-results h3 {
      font-size: 18px;
      color: #374151;
      margin: 0 0 8px 0;
    }

    .no-results p {
      margin: 0;
      font-size: 14px;
    }

    @media (max-width: 1024px) {
      .search-content {
        grid-template-columns: 1fr;
      }

      .filters-sidebar {
        order: 2;
      }

      .results-content {
        order: 1;
      }
    }

    @media (max-width: 768px) {
      .header-content {
        flex-direction: column;
        height: auto;
        padding: 16px 0;
        gap: 16px;
      }

      .search-wrapper {
        margin: 0;
        max-width: none;
      }

      .search-content {
        padding: 16px;
      }

      .results-grid {
        grid-template-columns: 1fr;
        padding: 16px;
      }
    }
  `]
})
export class SearchResultsComponent implements OnInit {
  searchQuery = '';
  originalQuery = '';
  allCourses: Course[] = [];
  filteredCourses: Course[] = [];
  paginatedCourses: Course[] = [];
  totalCourses = 0;
  sortBy = 'latest';

  filters = {
    duration: {
      all: true,
      lessThanWeek: false,
      oneToFourWeeks: false,
      oneToThreeMonths: false,
      threeToSixMonths: false,
      sixToTwelveMonths: false
    },
    rating: {
      all: true,
      fourFiveAndUp: false,
      fourAndUp: false,
      threeFiveAndUp: false,
      threeAndUp: false
    },
    publishedDate: {
      all: true,
      thisWeek: false,
      thisMonth: false,
      lastSixMonths: false,
      thisYear: false
    },
    courseLevel: {
      all: true,
      beginner: false,
      intermediate: false,
      advanced: false
    }
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private courseService: CourseService
  ) {}

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      this.searchQuery = params['q'] || '';
      this.originalQuery = this.searchQuery;
      this.loadCourses();
    });
  }

  loadCourses() {
    this.courseService.getAllCourses().subscribe(courses => {
      this.allCourses = courses;
      this.totalCourses = courses.length;
      this.performSearch();
    });
  }

  performSearch() {
    if (!this.searchQuery.trim()) {
      this.router.navigate(['/search'], { queryParams: { q: this.searchQuery } });
      return;
    }

    // Update URL
    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: { q: this.searchQuery },
      queryParamsHandling: 'merge'
    });

    this.originalQuery = this.searchQuery;
    this.applyFilters();
  }

  applyFilters() {
    let filtered = [...this.allCourses];

    // Apply search filter
    if (this.originalQuery.trim()) {
      const query = this.originalQuery.toLowerCase();
      filtered = filtered.filter(course =>
        course.title.toLowerCase().includes(query) ||
        course.subtitle?.toLowerCase().includes(query) ||
        course.provider.name.toLowerCase().includes(query) ||
        course.skills.some(skill => skill.toLowerCase().includes(query))
      );
    }

    // Apply duration filters
    if (!this.filters.duration.all) {
      filtered = filtered.filter(course => {
        const duration = course.durationText.toLowerCase();
        
        if (this.filters.duration.lessThanWeek) {
          if (duration.includes('day') || (duration.includes('week') && duration.includes('1'))) {
            return true;
          }
        }
        if (this.filters.duration.oneToFourWeeks) {
          if (duration.includes('week') && !duration.includes('month')) {
            return true;
          }
        }
        if (this.filters.duration.oneToThreeMonths) {
          if (duration.includes('month') && (duration.includes('1') || duration.includes('2') || duration.includes('3'))) {
            return true;
          }
        }
        if (this.filters.duration.threeToSixMonths) {
          if (duration.includes('month') && (duration.includes('3') || duration.includes('4') || duration.includes('5') || duration.includes('6'))) {
            return true;
          }
        }
        if (this.filters.duration.sixToTwelveMonths) {
          if (duration.includes('month') && (duration.includes('6') || duration.includes('7') || duration.includes('8') || duration.includes('9') || duration.includes('10') || duration.includes('11') || duration.includes('12'))) {
            return true;
          }
        }
        
        return false;
      });
    }

    // Apply rating filters
    if (!this.filters.rating.all) {
      console.log('Applying rating filters:', this.filters.rating);
      const beforeRatingFilter = filtered.length;
      filtered = filtered.filter(course => {
        if (this.filters.rating.fourFiveAndUp && course.rating >= 4.5) return true;
        if (this.filters.rating.fourAndUp && course.rating >= 4.0) return true;
        if (this.filters.rating.threeFiveAndUp && course.rating >= 3.5) return true;
        if (this.filters.rating.threeAndUp && course.rating >= 3.0) return true;
        return false;
      });
      console.log(`Rating filter: ${beforeRatingFilter} -> ${filtered.length} courses`);
    }

    // Apply published date filters
    if (!this.filters.publishedDate.all) {
      console.log('Applying published date filters:', this.filters.publishedDate);
      const now = new Date();
      const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const oneMonthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
      const sixMonthsAgo = new Date(now.getTime() - 6 * 30 * 24 * 60 * 60 * 1000);
      const oneYearAgo = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);

      console.log('Date ranges:', {
        now: now.toISOString(),
        oneWeekAgo: oneWeekAgo.toISOString(),
        oneMonthAgo: oneMonthAgo.toISOString(),
        sixMonthsAgo: sixMonthsAgo.toISOString(),
        oneYearAgo: oneYearAgo.toISOString()
      });

      const beforeDateFilter = filtered.length;
      filtered = filtered.filter(course => {
        const publishedDate = new Date(course.publishedDate);
        console.log(`Course "${course.title}" published: ${publishedDate.toISOString()}`);
        
        if (this.filters.publishedDate.thisWeek && publishedDate >= oneWeekAgo) {
          console.log(`✓ Course "${course.title}" matches thisWeek filter`);
          return true;
        }
        if (this.filters.publishedDate.thisMonth && publishedDate >= oneMonthAgo) {
          console.log(`✓ Course "${course.title}" matches thisMonth filter`);
          return true;
        }
        if (this.filters.publishedDate.lastSixMonths && publishedDate >= sixMonthsAgo) {
          console.log(`✓ Course "${course.title}" matches lastSixMonths filter`);
          return true;
        }
        if (this.filters.publishedDate.thisYear && publishedDate >= oneYearAgo) {
          console.log(`✓ Course "${course.title}" matches thisYear filter`);
          return true;
        }
        console.log(`✗ Course "${course.title}" doesn't match any date filter`);
        return false;
      });
      console.log(`Date filter: ${beforeDateFilter} -> ${filtered.length} courses`);
    }

    // Apply course level filters
    if (!this.filters.courseLevel.all) {
      filtered = filtered.filter(course => {
        const difficulty = course.difficulty.toLowerCase();
        
        if (this.filters.courseLevel.beginner && difficulty === 'beginner') return true;
        if (this.filters.courseLevel.intermediate && difficulty === 'intermediate') return true;
        if (this.filters.courseLevel.advanced && difficulty === 'advanced') return true;
        return false;
      });
    }

    this.filteredCourses = filtered;
    this.applySorting();
  }

  onDurationFilterChange(filterType: string) {
    if (filterType === 'all') {
      if (this.filters.duration.all) {
        // If "All" is checked, uncheck all other duration filters
        this.filters.duration.lessThanWeek = false;
        this.filters.duration.oneToFourWeeks = false;
        this.filters.duration.oneToThreeMonths = false;
        this.filters.duration.threeToSixMonths = false;
        this.filters.duration.sixToTwelveMonths = false;
      }
    } else {
      // If any specific filter is checked, uncheck "All"
      this.filters.duration.all = false;
    }
    this.applyFilters();
  }

  onRatingFilterChange(filterType: string) {
    if (filterType === 'all') {
      if (this.filters.rating.all) {
        this.filters.rating.fourFiveAndUp = false;
        this.filters.rating.fourAndUp = false;
        this.filters.rating.threeFiveAndUp = false;
        this.filters.rating.threeAndUp = false;
      }
    } else {
      this.filters.rating.all = false;
    }
    this.applyFilters();
  }

  onPublishedDateFilterChange(filterType: string) {
    if (filterType === 'all') {
      if (this.filters.publishedDate.all) {
        this.filters.publishedDate.thisWeek = false;
        this.filters.publishedDate.thisMonth = false;
        this.filters.publishedDate.lastSixMonths = false;
        this.filters.publishedDate.thisYear = false;
      }
    } else {
      this.filters.publishedDate.all = false;
    }
    this.applyFilters();
  }

  onCourseLevelFilterChange(filterType: string) {
    if (filterType === 'all') {
      if (this.filters.courseLevel.all) {
        this.filters.courseLevel.beginner = false;
        this.filters.courseLevel.intermediate = false;
        this.filters.courseLevel.advanced = false;
      }
    } else {
      this.filters.courseLevel.all = false;
    }
    this.applyFilters();
  }

  applySorting() {
    switch (this.sortBy) {
      case 'rating':
        this.filteredCourses.sort((a, b) => b.rating - a.rating);
        break;
      case 'alphabetical':
        this.filteredCourses.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'duration':
        this.filteredCourses.sort((a, b) => a.durationText.localeCompare(b.durationText));
        break;
      case 'latest':
      default:
        this.filteredCourses.sort((a, b) => 
          new Date(b.publishedDate).getTime() - new Date(a.publishedDate).getTime()
        );
        break;
    }

    this.paginatedCourses = this.filteredCourses; // For now, show all results
  }

  clearSearch() {
    this.searchQuery = '';
    this.performSearch();
  }

  getEnrollmentForCourse(courseId: number) {
    // This would normally come from a service
    return undefined;
  }

  getSkillsText(skills: string[]): string {
    if (!skills || skills.length === 0) return '';
    
    if (skills.length <= 3) {
      return skills.join(', ');
    } else {
      return skills.slice(0, 3).join(', ') + '...';
    }
  }

  formatNumber(num: number): string {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  goToDashboard() {
    this.router.navigate(['/dashboard']);
  }
}
