import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { SearchResultsComponent } from './components/search-results/search-results.component';
import { CourseDetailComponent } from './components/course-detail/course-detail.component';
import { CourseLearnComponent } from './components/course-learn/course-learn.component';
import { AuthGuard } from './guards/auth.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'search', component: SearchResultsComponent, canActivate: [AuthGuard] },
  { path: 'course/:id', component: CourseDetailComponent, canActivate: [AuthGuard] },
  { path: 'learn/:courseId/lecture/:lectureId', component: CourseLearnComponent, canActivate: [AuthGuard] },
  { path: 'learn/:courseId', component: CourseLearnComponent, canActivate: [AuthGuard] },
  { path: '**', redirectTo: '/login' }
];
