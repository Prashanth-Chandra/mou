import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';
import { map, catchError, switchMap } from 'rxjs/operators';
import { Course, UserEnrollment } from '../models/course.model';
import { Enrollment, UserProgress, CourseProgress } from '../models/enrollment.model';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  private apiUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  getAllCourses(): Observable<Course[]> {
    return this.http.get<Course[]>(`${this.apiUrl}/courses`);
  }

  getCourseById(id: number): Observable<Course> {
    return this.http.get<Course>(`${this.apiUrl}/courses/${id}`);
  }

  getUserEnrollments(userId: string): Observable<UserEnrollment[]> {
    return this.getAllUserEnrollments().pipe(
      map(allEnrollments => allEnrollments[userId] || [])
    );
  }

  getAllUserEnrollments(): Observable<{[key: string]: UserEnrollment[]}> {
    return this.http.get<{[key: string]: UserEnrollment[]}>(`${this.apiUrl}/userEnrollments`);
  }

  searchCourses(query: string): Observable<Course[]> {
    return this.getAllCourses().pipe(
      map(courses => {
        const lowercaseQuery = query.toLowerCase();
        return courses.filter(course => 
          course.title.toLowerCase().includes(lowercaseQuery) ||
          course.subtitle?.toLowerCase().includes(lowercaseQuery) ||
          course.provider.name.toLowerCase().includes(lowercaseQuery) ||
          course.skills.some(skill => skill.toLowerCase().includes(lowercaseQuery)) ||
          course.difficulty.toLowerCase().includes(lowercaseQuery)
        );
      })
    );
  }

  getLastViewedCourses(userId: string): Observable<Course[]> {
    // Simulate getting last viewed courses by randomly selecting from all courses
    return this.getAllCourses().pipe(
      map(courses => {
        // Shuffle the array and take first 6
        const shuffled = courses.sort(() => 0.5 - Math.random());
        return shuffled.slice(0, 6);
      })
    );
  }

  getNewlyLaunchedCourses(): Observable<Course[]> {
    return this.getAllCourses().pipe(
      map(courses => {
        // Shuffle the array and take a different set of 6 for "newly launched"
        const shuffled = courses.sort(() => 0.5 - Math.random());
        return shuffled.slice(0, 6);
      })
    );
  }

  getCourseCurriculum(courseId: string): Observable<any[]> {
    return this.http.get<{[key: string]: any[]}>(`${this.apiUrl}/curriculum`).pipe(
      map(allCurriculum => allCurriculum[courseId] || [])
    );
  }

  getCourseReviews(courseId: string): Observable<any[]> {
    return this.http.get<{[key: string]: any[]}>(`${this.apiUrl}/reviews`).pipe(
      map(allReviews => allReviews[courseId] || [])
    );
  }

  getUserById(userId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/users/${userId}`);
  }

  // Enrollment Management
  getUserEnrollmentsNew(userId: string): Observable<Enrollment[]> {
    return this.http.get<Enrollment[]>(`${this.apiUrl}/enrollments`).pipe(
      map(enrollments => enrollments.filter(enrollment => enrollment.userId === userId))
    );
  }

  enrollUserInCourse(userId: string, courseId: string): Observable<Enrollment> {
    const enrollment: Omit<Enrollment, 'id'> = {
      userId,
      courseId,
      enrolledDate: new Date().toISOString(),
      status: 'active',
      completionPercentage: 0,
      lastAccessedDate: new Date().toISOString()
    };

    return this.http.post<Enrollment>(`${this.apiUrl}/enrollments`, enrollment);
  }

  isUserEnrolled(userId: string, courseId: string): Observable<boolean> {
    return this.getUserEnrollmentsNew(userId).pipe(
      map(enrollments => enrollments.some(enrollment => 
        enrollment.courseId === courseId && enrollment.status === 'active'
      ))
    );
  }

  // Progress Tracking
  getUserProgress(userId: string, courseId: string): Observable<UserProgress[]> {
    return this.http.get<UserProgress[]>(`${this.apiUrl}/userProgress`).pipe(
      map(progress => progress.filter(p => 
        p.userId === userId && p.courseId === courseId
      ))
    );
  }

  markLectureAsComplete(userId: string, courseId: string, lectureId: string): Observable<UserProgress> {
    return this.getUserProgress(userId, courseId).pipe(
      map(progressList => {
        const existingProgress = progressList.find(p => p.lectureId === lectureId);
        return { existingProgress, progressList };
      }),
      map(({ existingProgress }) => {
        if (existingProgress) {
          // Update existing progress
          const updatedProgress = {
            ...existingProgress,
            completed: true,
            watchedDate: new Date().toISOString()
          };
          return this.http.put<UserProgress>(
            `${this.apiUrl}/userProgress/${existingProgress.id}`, 
            updatedProgress
          );
        } else {
          // Create new progress entry
          const newProgress: Omit<UserProgress, 'id'> = {
            userId,
            courseId,
            lectureId,
            completed: true,
            watchedDate: new Date().toISOString(),
            watchTime: 0,
            totalDuration: 0
          };
          return this.http.post<UserProgress>(`${this.apiUrl}/userProgress`, newProgress);
        }
      }),
      // Flatten the nested observable
      switchMap(progressObs => progressObs)
    );
  }

  updateLectureProgress(userId: string, courseId: string, lectureId: string, watchTime: number, totalDuration: number): Observable<UserProgress> {
    return this.getUserProgress(userId, courseId).pipe(
      map(progressList => {
        const existingProgress = progressList.find(p => p.lectureId === lectureId);
        
        if (existingProgress) {
          const updatedProgress = {
            ...existingProgress,
            watchTime,
            totalDuration,
            watchedDate: new Date().toISOString()
          };
          return this.http.put<UserProgress>(
            `${this.apiUrl}/userProgress/${existingProgress.id}`, 
            updatedProgress
          );
        } else {
          const newProgress: Omit<UserProgress, 'id'> = {
            userId,
            courseId,
            lectureId,
            completed: false,
            watchedDate: new Date().toISOString(),
            watchTime,
            totalDuration
          };
          return this.http.post<UserProgress>(`${this.apiUrl}/userProgress`, newProgress);
        }
      }),
      // Flatten the nested observable
      switchMap(progressObs => progressObs)
    );
  }

  getCourseProgress(userId: string, courseId: string): Observable<CourseProgress> {
    return forkJoin({
      curriculum: this.getCourseCurriculum(courseId),
      progress: this.getUserProgress(userId, courseId),
      enrollment: this.getUserEnrollmentsNew(userId).pipe(
        map(enrollments => enrollments.find(e => e.courseId === courseId))
      )
    }).pipe(
      map(({ curriculum, progress, enrollment }) => {
        const totalLectures = curriculum.reduce((total, section) => 
          total + section.lectures.length, 0
        );
        
        const completedLectures = progress.filter(p => p.completed).length;
        const completionPercentage = totalLectures > 0 ? 
          Math.round((completedLectures / totalLectures) * 100) : 0;
        
        const totalWatchTime = progress.reduce((total, p) => total + p.watchTime, 0);
        
        const lastWatchedProgress = progress
          .filter(p => p.watchedDate)
          .sort((a, b) => new Date(b.watchedDate!).getTime() - new Date(a.watchedDate!).getTime())[0];

        return {
          courseId,
          totalLectures,
          completedLectures,
          completionPercentage,
          totalWatchTime,
          lastWatchedLecture: lastWatchedProgress?.lectureId,
          enrollment: enrollment!
        } as CourseProgress;
      })
    );
  }

  updateEnrollmentProgress(userId: string, courseId: string): Observable<Enrollment> {
    return forkJoin({
      enrollment: this.getUserEnrollmentsNew(userId).pipe(
        map(enrollments => enrollments.find(e => e.courseId === courseId))
      ),
      courseProgress: this.getCourseProgress(userId, courseId)
    }).pipe(
      switchMap(({ enrollment, courseProgress }) => {
        if (!enrollment) throw new Error('Enrollment not found');
        
        const updatedEnrollment = {
          ...enrollment,
          completionPercentage: courseProgress.completionPercentage,
          lastAccessedDate: new Date().toISOString(),
          status: courseProgress.completionPercentage === 100 ? 'completed' as const : 'active' as const
        };
        
        return this.http.put<Enrollment>(
          `${this.apiUrl}/enrollments/${enrollment.id}`, 
          updatedEnrollment
        );
      })
    );
  }
}
