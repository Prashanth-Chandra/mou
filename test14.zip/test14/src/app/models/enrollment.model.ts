export interface Enrollment {
  id: string;
  userId: string;
  courseId: string;
  enrolledDate: string;
  status: 'active' | 'completed' | 'paused' | 'cancelled';
  completionPercentage: number;
  lastAccessedDate: string;
}

export interface UserProgress {
  id: string;
  userId: string;
  courseId: string;
  lectureId: string;
  completed: boolean;
  watchedDate: string | null;
  watchTime: number; // in seconds
  totalDuration: number; // in seconds
}

export interface CourseProgress {
  courseId: string;
  totalLectures: number;
  completedLectures: number;
  completionPercentage: number;
  totalWatchTime: number;
  lastWatchedLecture?: string;
  enrollment: Enrollment;
}
