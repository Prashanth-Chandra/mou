import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CourseService } from '../../services/course.service';
import { User } from '../../models/user.model';
import { Course } from '../../models/course.model';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <header class="app-header">
      <div class="header-content">
        <h1 class="product-name" (click)="goToDashboard()">Product Name</h1>
        
        <div class="search-wrapper">
          <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          <input 
            type="text" 
            class="search-input"
            placeholder="Search Courses"
            [(ngModel)]="searchQuery"
            (input)="onSearchInput($event)"
            (focus)="onSearchFocus()"
            (blur)="onSearchBlur()"
          />
          <button 
            class="clear-button" 
            *ngIf="searchQuery" 
            (click)="clearSearch()"
            type="button">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
          
          <!-- Search Results Dropdown -->
          <div class="search-results" *ngIf="showSearchResults && searchResults.length > 0">
            <div 
              class="search-result-item" 
              *ngFor="let course of searchResults | slice:0:5"
              (click)="selectCourse(course)">
              <img [src]="course.thumbnailUrl" [alt]="course.title" class="result-thumbnail" />
              <div class="result-content">
                <h4 class="result-title">{{ course.title }}</h4>
                <p class="result-instructor">{{ course.provider.name }}</p>
                <div class="result-meta">
                  <span class="result-duration">{{ course.durationText }}</span>
                  <span class="result-level">{{ course.difficulty }}</span>
                </div>
              </div>
            </div>
            <div class="search-footer" *ngIf="searchResults.length > 5">
              <p>{{ searchResults.length - 5 }} more results...</p>
            </div>
          </div>
        </div>

        <div class="header-actions">
          <div class="notification-icon" (click)="toggleNotifications()">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            </svg>
            <span class="notification-badge">1</span>
          </div>
          
          <div class="user-menu" *ngIf="currentUser">
            <img [src]="currentUser.avatarUrl" [alt]="currentUser.fullName" class="user-avatar" (click)="toggleUserMenu()" />
            <div class="user-dropdown" [class.show]="showUserMenu">
              <div class="user-info">
                <div class="user-avatar-large">
                  <img [src]="currentUser.avatarUrl" [alt]="currentUser.fullName" class="dropdown-avatar" />
                </div>
                <div class="user-details">
                  <p class="user-name">{{ currentUser.fullName }}</p>
                  <p class="user-role">{{ currentUser.track || currentUser.role }}</p>
                </div>
              </div>
              <hr>
              <button class="dropdown-item" (click)="navigateToProfile()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                  <circle cx="12" cy="7" r="4"></circle>
                </svg>
                My Profile
              </button>
              <button class="dropdown-item" (click)="navigateToSettings()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <circle cx="12" cy="12" r="3"></circle>
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1 1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
                Settings
              </button>
              <hr>
              <button class="dropdown-item logout" (click)="logout()">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                  <polyline points="16,17 21,12 16,7"></polyline>
                  <line x1="21" y1="12" x2="9" y2="12"></line>
                </svg>
                Logout
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  `,
  styles: [`
    .app-header {
      background: white;
      border-bottom: 1px solid #e5e7eb;
      padding: 0 24px;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1400px;
      margin: 0 auto;
      height: 64px;
      gap: 24px;
    }

    .product-name {
      font-size: 20px;
      font-weight: 600;
      color: #111827;
      margin: 0;
      cursor: pointer;
      transition: color 0.2s ease;
      flex-shrink: 0;
    }

    .product-name:hover {
      color: #3b82f6;
    }

    .search-wrapper {
      position: relative;
      flex: 1;
      max-width: 500px;
      margin: 0 auto;
    }

    .search-wrapper .search-icon {
      position: absolute;
      left: 12px;
      top: 50%;
      transform: translateY(-50%);
      color: #6b7280;
      z-index: 1;
    }

    .search-input {
      width: 100%;
      padding: 12px 16px 12px 44px;
      border: 1px solid #d1d5db;
      border-radius: 8px;
      font-size: 14px;
      background: #f9fafb;
      transition: all 0.2s ease;
      outline: none;
    }

    .search-input:focus {
      background: white;
      border-color: #3b82f6;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }

    .search-input::placeholder {
      color: #9ca3af;
    }

    .clear-button {
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      color: #6b7280;
      cursor: pointer;
      padding: 4px;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .clear-button:hover {
      background: #f3f4f6;
      color: #374151;
    }

    .search-results {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      z-index: 1000;
      max-height: 400px;
      overflow-y: auto;
    }

    .search-result-item {
      display: flex;
      align-items: center;
      padding: 12px 16px;
      cursor: pointer;
      transition: background 0.2s ease;
      gap: 12px;
    }

    .search-result-item:hover {
      background: #f9fafb;
    }

    .search-result-item:not(:last-child) {
      border-bottom: 1px solid #f3f4f6;
    }

    .result-thumbnail {
      width: 40px;
      height: 40px;
      border-radius: 6px;
      object-fit: cover;
      flex-shrink: 0;
    }

    .result-content {
      flex: 1;
      min-width: 0;
    }

    .result-title {
      font-size: 14px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 4px 0;
      line-height: 1.4;
    }

    .result-instructor {
      font-size: 12px;
      color: #6b7280;
      margin: 0 0 4px 0;
    }

    .result-meta {
      display: flex;
      gap: 8px;
      font-size: 11px;
      color: #9ca3af;
    }

    .search-footer {
      padding: 8px 16px;
      background: #f9fafb;
      border-top: 1px solid #f3f4f6;
      text-align: center;
    }

    .search-footer p {
      margin: 0;
      font-size: 12px;
      color: #6b7280;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 16px;
      flex-shrink: 0;
    }

    .notification-icon {
      position: relative;
      cursor: pointer;
      color: #6b7280;
      padding: 8px;
      border-radius: 50%;
      transition: all 0.2s ease;
    }

    .notification-icon:hover {
      background: #f3f4f6;
      color: #111827;
    }

    .notification-badge {
      position: absolute;
      top: 4px;
      right: 4px;
      background: #ef4444;
      color: white;
      border-radius: 50%;
      width: 16px;
      height: 16px;
      font-size: 10px;
      font-weight: 600;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid white;
    }

    .user-menu {
      position: relative;
    }

    .user-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      cursor: pointer;
      border: 2px solid #e5e7eb;
      transition: border-color 0.2s ease;
    }

    .user-avatar:hover {
      border-color: #3b82f6;
    }

    .user-dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      min-width: 240px;
      opacity: 0;
      visibility: hidden;
      transform: translateY(-10px);
      transition: all 0.3s ease;
      z-index: 1000;
    }

    .user-dropdown.show {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }

    .user-info {
      display: flex;
      align-items: center;
      padding: 16px;
      gap: 12px;
    }

    .user-avatar-large {
      flex-shrink: 0;
    }

    .dropdown-avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      border: 2px solid #e5e7eb;
    }

    .user-details {
      flex: 1;
      min-width: 0;
    }

    .user-name {
      font-weight: 600;
      color: #111827;
      margin: 0 0 4px 0;
      font-size: 14px;
    }

    .user-role {
      color: #6b7280;
      margin: 0;
      font-size: 12px;
    }

    .user-dropdown hr {
      margin: 0;
      border: none;
      border-top: 1px solid #e5e7eb;
    }

    .dropdown-item {
      width: 100%;
      padding: 12px 16px;
      border: none;
      background: none;
      text-align: left;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 14px;
      color: #374151;
      transition: background 0.2s ease;
    }

    .dropdown-item:hover {
      background: #f3f4f6;
    }

    .dropdown-item.logout {
      color: #dc2626;
    }

    .dropdown-item.logout:hover {
      background: #fef2f2;
    }

    .dropdown-item svg {
      flex-shrink: 0;
    }

    @media (max-width: 768px) {
      .header-content {
        padding: 0 16px;
        height: 56px;
      }

      .product-name {
        font-size: 18px;
      }

      .user-dropdown {
        min-width: 200px;
      }

      .user-info {
        padding: 12px;
      }

      .dropdown-avatar {
        width: 40px;
        height: 40px;
      }

      .dropdown-item {
        padding: 10px 12px;
        font-size: 13px;
      }
    }
  `]
})
export class HeaderComponent implements OnInit, OnDestroy {
  currentUser: User | null = null;
  showUserMenu: boolean = false;
  searchQuery: string = '';
  searchResults: Course[] = [];
  showSearchResults: boolean = false;
  private userSubscription: Subscription = new Subscription();

  constructor(
    private authService: AuthService,
    private courseService: CourseService,
    private router: Router
  ) {}

  ngOnInit() {
    // Subscribe to current user from auth service
    this.userSubscription = this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
    });

    // If no user is logged in (for demo purposes), check if we need to set a default user
    // This would normally be handled by a proper authentication flow
    if (!this.authService.getCurrentUser()) {
      // For demo purposes, we'll create a mock user and store it in localStorage
      // const mockUser: User = {
      //   id: 1,
      //   username: 'hshimron',
      //   email: 'harry.shimron@example.com',
      //   password: 'hashed_password',
      //   fullName: 'Harry Shimron',
      //   track: 'DC Software Engineer II',
      //   avatarUrl: 'https://i.pravatar.cc/150?u=hshimron',
      //   joinDate: '2021-08-14T00:00:00.000Z',
      //   role: 'Admin',
      //   bio: 'Passionate learner and developer',
      //   location: 'Bangalore, India'
      // };
      
      // Store in localStorage and trigger the auth service to pick it up
      // localStorage.setItem('currentUser', JSON.stringify(mockUser));
      // Trigger auth service to check stored auth again
      this.authService.refreshStoredAuth();
    }
  }

  ngOnDestroy() {
    this.userSubscription.unsubscribe();
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: Event) {
    const target = event.target as HTMLElement;
    const userMenu = target.closest('.user-menu');
    const searchWrapper = target.closest('.search-wrapper');
    
    if (!userMenu) {
      this.showUserMenu = false;
    }
    if (!searchWrapper) {
      this.showSearchResults = false;
    }
  }

  toggleUserMenu() {
    this.showUserMenu = !this.showUserMenu;
  }

  toggleNotifications() {
    // Handle notification click
    console.log('Notifications clicked');
  }

  onSearchInput(event: any) {
    const query = event.target.value;
    if (query.length > 2) {
      this.courseService.searchCourses(query).subscribe(results => {
        this.searchResults = results;
        this.showSearchResults = true;
      });
    } else {
      this.searchResults = [];
      this.showSearchResults = false;
    }
  }

  onSearchFocus() {
    if (this.searchQuery.length > 2) {
      this.showSearchResults = true;
    }
  }

  onSearchBlur() {
    // Delay hiding to allow click on results
    setTimeout(() => {
      this.showSearchResults = false;
    }, 200);
  }

  clearSearch() {
    this.searchQuery = '';
    this.searchResults = [];
    this.showSearchResults = false;
  }

  selectCourse(course: Course) {
    this.router.navigate(['/course', course.id]);
    this.clearSearch();
  }

  goToDashboard() {
    this.router.navigate(['/dashboard']);
  }

  navigateToProfile() {
    this.showUserMenu = false;
    this.router.navigate(['/profile']);
  }

  navigateToSettings() {
    this.showUserMenu = false;
    this.router.navigate(['/settings']);
  }

  logout() {
    this.showUserMenu = false;
    // In a real app, this would call the auth service
    this.router.navigate(['/login']);
  }
}
