import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Course, UserEnrollment } from '../models/course.model';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  private apiUrl = 'http://localhost:3000';

  constructor(private http: HttpClient) {}

  getAllCourses(): Observable<Course[]> {
    return this.http.get<Course[]>(`${this.apiUrl}/courses`);
  }

  getCourseById(id: number): Observable<Course> {
    return this.http.get<Course>(`${this.apiUrl}/courses/${id}`);
  }

  getUserEnrollments(userId: string): Observable<UserEnrollment[]> {
    return this.getAllUserEnrollments().pipe(
      map(allEnrollments => allEnrollments[userId] || [])
    );
  }

  getAllUserEnrollments(): Observable<{[key: string]: UserEnrollment[]}> {
    return this.http.get<{[key: string]: UserEnrollment[]}>(`${this.apiUrl}/userEnrollments`);
  }

  searchCourses(query: string): Observable<Course[]> {
    return this.getAllCourses().pipe(
      map(courses => {
        const lowercaseQuery = query.toLowerCase();
        return courses.filter(course => 
          course.title.toLowerCase().includes(lowercaseQuery) ||
          course.subtitle?.toLowerCase().includes(lowercaseQuery) ||
          course.provider.name.toLowerCase().includes(lowercaseQuery) ||
          course.skills.some(skill => skill.toLowerCase().includes(lowercaseQuery)) ||
          course.difficulty.toLowerCase().includes(lowercaseQuery)
        );
      })
    );
  }

  getLastViewedCourses(userId: string): Observable<Course[]> {
    // Simulate getting last viewed courses by randomly selecting from all courses
    return this.getAllCourses().pipe(
      map(courses => {
        // Shuffle the array and take first 6
        const shuffled = courses.sort(() => 0.5 - Math.random());
        return shuffled.slice(0, 6);
      })
    );
  }

  getNewlyLaunchedCourses(): Observable<Course[]> {
    return this.getAllCourses().pipe(
      map(courses => {
        // Shuffle the array and take a different set of 6 for "newly launched"
        const shuffled = courses.sort(() => 0.5 - Math.random());
        return shuffled.slice(0, 6);
      })
    );
  }

  getCourseCurriculum(courseId: string): Observable<any[]> {
    return this.http.get<{[key: string]: any[]}>(`${this.apiUrl}/curriculum`).pipe(
      map(allCurriculum => allCurriculum[courseId] || [])
    );
  }

  getCourseReviews(courseId: string): Observable<any[]> {
    return this.http.get<{[key: string]: any[]}>(`${this.apiUrl}/reviews`).pipe(
      map(allReviews => allReviews[courseId] || [])
    );
  }

  getUserById(userId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/users/${userId}`);
  }
}
