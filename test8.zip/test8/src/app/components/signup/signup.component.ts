import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="signup-container">
      <div class="signup-left">
        <img src="/assets/signup/image.png" alt="Sign up illustration" class="signup-image" />
      </div>
      <div class="signup-right">
        <div class="signup-form-wrapper">
          <h1 class="product-name">Product Name</h1>
          <h2 class="signup-title">Sign up</h2>
          <p class="signup-subtitle">Enter details mentioned below</p>
          
          <form [formGroup]="signupForm" (ngSubmit)="onSubmit()">
            <div class="form-group">
              <input 
                type="text" 
                placeholder="Full Name" 
                class="signup-input"
                formControlName="fullName"
                [class.error]="signupForm.get('fullName')?.invalid && signupForm.get('fullName')?.touched"
              />
              <div class="error-message" *ngIf="signupForm.get('fullName')?.invalid && signupForm.get('fullName')?.touched">
                Full name is required
              </div>
            </div>

            <div class="form-group">
              <input 
                type="text" 
                placeholder="User Name" 
                class="signup-input"
                formControlName="username"
                [class.error]="signupForm.get('username')?.invalid && signupForm.get('username')?.touched"
              />
              <div class="error-message" *ngIf="signupForm.get('username')?.invalid && signupForm.get('username')?.touched">
                <span *ngIf="signupForm.get('username')?.errors?.['required']">Username is required</span>
                <span *ngIf="signupForm.get('username')?.errors?.['minlength']">Username must be at least 3 characters</span>
              </div>
            </div>

            <div class="form-group">
              <input 
                type="email" 
                placeholder="Email" 
                class="signup-input"
                formControlName="email"
                [class.error]="signupForm.get('email')?.invalid && signupForm.get('email')?.touched"
              />
              <div class="error-message" *ngIf="signupForm.get('email')?.invalid && signupForm.get('email')?.touched">
                <span *ngIf="signupForm.get('email')?.errors?.['required']">Email is required</span>
                <span *ngIf="signupForm.get('email')?.errors?.['email']">Please enter a valid email</span>
              </div>
            </div>

            <div class="form-group">
              <div class="password-wrapper">
                <input 
                  [type]="showPassword ? 'text' : 'password'" 
                  placeholder="Password" 
                  class="signup-input password-input"
                  formControlName="password"
                  [class.error]="signupForm.get('password')?.invalid && signupForm.get('password')?.touched"
                />
                <span class="toggle-password" (click)="togglePassword()">
                  <svg *ngIf="!showPassword" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/>
                  </svg>
                  <svg *ngIf="showPassword" width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.878 9.878L3 3m6.878 6.878L21 21"/>
                  </svg>
                </span>
              </div>
              <div class="error-message" *ngIf="signupForm.get('password')?.invalid && signupForm.get('password')?.touched">
                <span *ngIf="signupForm.get('password')?.errors?.['required']">Password is required</span>
                <span *ngIf="signupForm.get('password')?.errors?.['minlength']">Password must be at least 6 characters</span>
              </div>
            </div>

            <div class="form-group">
              <div class="checkbox-wrapper">
                <input type="checkbox" id="terms" formControlName="agreeToTerms" />
                <label for="terms">I agree to the terms and conditions by signing up</label>
              </div>
              <div class="error-message" *ngIf="signupForm.get('agreeToTerms')?.invalid && signupForm.get('agreeToTerms')?.touched">
                You must agree to the terms and conditions
              </div>
            </div>

            <div class="error-message" *ngIf="errorMessage">
              {{ errorMessage }}
            </div>

            <div class="success-message" *ngIf="successMessage">
              {{ successMessage }}
            </div>

            <button type="submit" class="register-btn" [disabled]="signupForm.invalid || isLoading">
              <span *ngIf="isLoading">Creating Account...</span>
              <span *ngIf="!isLoading">Register</span>
            </button>
          </form>

          <p class="login-link">Already have an Account? <a routerLink="/login">Login</a></p>
        </div>
      </div>
    </div>
  `,
  styleUrls: ['./signup.component.css']
})
export class SignupComponent {
  signupForm: FormGroup;
  showPassword = false;
  isLoading = false;
  errorMessage = '';
  successMessage = '';

  constructor(
    private fb: FormBuilder,
    private authService: AuthService,
    private router: Router
  ) {
    this.signupForm = this.fb.group({
      fullName: ['', [Validators.required]],
      username: ['', [Validators.required, Validators.minLength(3)]],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      agreeToTerms: [false, [Validators.requiredTrue]]
    });
  }

  togglePassword(): void {
    this.showPassword = !this.showPassword;
  }

  onSubmit(): void {
    if (this.signupForm.valid) {
      this.isLoading = true;
      this.errorMessage = '';
      this.successMessage = '';

      const signupData = {
        fullName: this.signupForm.value.fullName,
        username: this.signupForm.value.username,
        email: this.signupForm.value.email,
        password: this.signupForm.value.password
      };

      this.authService.signup(signupData).subscribe({
        next: (result: any) => {
          this.isLoading = false;
          if (result.success) {
            this.successMessage = 'Account created successfully! Redirecting to dashboard...';
            setTimeout(() => {
              this.router.navigate(['/dashboard']);
            }, 2000);
          } else {
            this.errorMessage = result.message || 'Signup failed';
          }
        },
        error: (error: any) => {
          this.isLoading = false;
          this.errorMessage = 'An error occurred. Please try again.';
          console.error('Signup error:', error);
        }
      });
    }
  }
}
