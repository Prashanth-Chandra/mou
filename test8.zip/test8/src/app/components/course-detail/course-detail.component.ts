import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { CourseService } from '../../services/course.service';
import { Course } from '../../models/course.model';

@Component({
  selector: 'app-course-detail',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="course-detail-container" *ngIf="course">
      <!-- Header -->
      <header class="course-header">
        <div class="header-content">
          <h1 class="product-name">Product Name</h1>
          <div class="search-wrapper">
            <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.35-4.35"></path>
            </svg>
            <input 
              type="text" 
              class="search-input"
              placeholder="Search Courses"
            />
            <button class="clear-button" type="button">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
          <div class="header-actions">
            <div class="notification-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              <span class="notification-badge">1</span>
            </div>
            <div class="user-avatar" (click)="goToDashboard()">
              <img src="assets/user-avatar.png" alt="User" />
            </div>
          </div>
        </div>
      </header>

      <!-- Breadcrumb -->
      <div class="breadcrumb-container">
        <div class="breadcrumb-content">
          <a href="#" (click)="goToHome()" class="breadcrumb-link">Home</a>
          <span class="breadcrumb-separator">></span>
          <span class="breadcrumb-current">{{ course.title }}</span>
        </div>
      </div>

      <!-- Course Hero Section -->
      <div class="course-hero">
        <div class="hero-content">
          <div class="course-info">
            <h1 class="course-title">{{ course.title }}</h1>
            <p class="course-subtitle">{{ course.subtitle }}</p>
            
            <div class="author-info">
              <span class="created-by">Created by: </span>
              <a href="#" class="author-link">{{ getAuthorName() }}</a>
            </div>

            <button class="enroll-button">Enroll Now</button>
            
            <div class="enrollment-info">
              <span class="enrollment-count">{{ formatNumber(course.enrollmentCount) }} already enrolled</span>
            </div>
          </div>
          
          <div class="course-visual">
            <div class="decorative-circles">
              <div class="circle circle-1"></div>
              <div class="circle circle-2"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Course Meta Info -->
      <div class="course-meta-section">
        <div class="meta-content">
          <div class="meta-item">
            <span class="meta-label">Level</span>
            <span class="meta-value">{{ course.difficulty }} Level</span>
          </div>
          <div class="meta-item">
            <span class="meta-label">Rating</span>
            <div class="rating-info">
              <span class="rating-value">{{ course.rating }}</span>
              <svg class="star" width="16" height="16" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
              <span class="review-count">({{ formatNumber(course.reviewCount) }} reviews)</span>
            </div>
          </div>
          <div class="meta-item">
            <span class="meta-label">Duration</span>
            <span class="meta-value">{{ course.durationText }}</span>
          </div>
          <div class="meta-item">
            <span class="meta-label">Flexible Schedule</span>
            <span class="meta-value">Learn at your own pace</span>
          </div>
        </div>
      </div>

      <!-- Course Content Tabs -->
      <div class="course-content-section">
        <div class="content-wrapper">
          <div class="tab-navigation">
            <button 
              class="tab-button"
              [class.active]="activeTab === 'overview'"
              (click)="setActiveTab('overview')"
            >
              Overview
            </button>
            <button 
              class="tab-button"
              [class.active]="activeTab === 'content'"
              (click)="setActiveTab('content')"
            >
              Course Content
            </button>
            <button 
              class="tab-button"
              [class.active]="activeTab === 'author'"
              (click)="setActiveTab('author')"
            >
              Author Details
            </button>
            <button 
              class="tab-button"
              [class.active]="activeTab === 'testimonials'"
              (click)="setActiveTab('testimonials')"
            >
              Testimonials
            </button>
          </div>

          <div class="tab-content">
            <!-- Overview Tab -->
            <div *ngIf="activeTab === 'overview'" class="tab-panel">
              <div class="overview-content">
                <section class="what-youll-learn">
                  <h3>What you'll Learn</h3>
                  <ul class="learning-objectives">
                    <li *ngFor="let objective of course.whatYoullLearn">{{ objective }}</li>
                  </ul>
                </section>

                <section class="skills-section">
                  <h3>Skills you'll gain</h3>
                  <div class="skills-tags">
                    <span *ngFor="let skill of course.skills" class="skill-tag">{{ skill }}</span>
                  </div>
                </section>

                <section class="requirements-section">
                  <h3>Requirements</h3>
                  <ul class="requirements-list">
                    <li *ngFor="let requirement of course.requirements">{{ requirement }}</li>
                  </ul>
                </section>

                <section class="description-section">
                  <h3>Description</h3>
                  <p class="course-description">{{ getCourseDescription() }}</p>
                </section>
              </div>
            </div>

            <!-- Course Content Tab -->
            <div *ngIf="activeTab === 'content'" class="tab-panel">
              <div class="course-content">
                <h3>Course Curriculum</h3>
                <div class="curriculum-section" *ngFor="let section of getCurriculum()">
                  <div class="section-header">
                    <h4 class="section-title">{{ section.title }}</h4>
                    <span class="section-count">{{ section.lectures?.length || 0 }} lectures</span>
                  </div>
                  <ul class="lecture-list" *ngIf="section.lectures">
                    <li *ngFor="let lecture of section.lectures" class="lecture-item">
                      <div class="lecture-info">
                        <span class="lecture-title">{{ lecture.title }}</span>
                        <div class="lecture-meta">
                          <span class="lecture-type">{{ lecture.type }}</span>
                          <span class="lecture-duration" *ngIf="lecture.durationMinutes">{{ lecture.durationMinutes }} min</span>
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
                <div *ngIf="getCurriculum().length === 0" class="no-curriculum">
                  <p>Curriculum information is not available for this course.</p>
                </div>
              </div>
            </div>

            <!-- Author Details Tab -->
            <div *ngIf="activeTab === 'author'" class="tab-panel">
              <div class="author-content">
                <h3>About the Instructor</h3>
                <p>{{ getAuthorName() }} - Expert in the field with years of experience.</p>
              </div>
            </div>

            <!-- Testimonials Tab -->
            <div *ngIf="activeTab === 'testimonials'" class="tab-panel">
              <div class="testimonials-content">
                <h3>Student Reviews</h3>
                <div class="reviews-container" *ngIf="getReviews().length > 0">
                  <div class="review-item" *ngFor="let review of getReviews()">
                    <div class="review-header">
                      <div class="reviewer-info">
                        <h4 class="reviewer-name">{{ getUserName(review.userId) }}</h4>
                        <div class="review-rating">
                          <span *ngFor="let star of getStarArray(review.rating)" class="star-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" [class.filled]="star">
                              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                            </svg>
                          </span>
                          <span class="rating-number">{{ review.rating }}/5</span>
                        </div>
                      </div>
                    </div>
                    <div class="review-content">
                      <p>"{{ review.comment }}"</p>
                    </div>
                  </div>
                </div>
                <div *ngIf="getReviews().length === 0" class="no-reviews">
                  <p>No reviews available for this course yet.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div *ngIf="!course" class="loading">
      <p>Loading course details...</p>
    </div>
  `,
  styles: [`
    .course-detail-container {
      min-height: 100vh;
      background: #f8fafc;
    }

    /* Header Styles */
    .course-header {
      background: white;
      border-bottom: 1px solid #e5e7eb;
      padding: 0 24px;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 64px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .product-name {
      font-size: 20px;
      font-weight: 600;
      color: #111827;
      margin: 0;
      cursor: pointer;
    }

    .search-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      background: white;
      border: 2px solid #e5e7eb;
      border-radius: 8px;
      padding: 0 12px;
      max-width: 600px;
      flex: 1;
      margin: 0 24px;
    }

    .search-icon {
      color: #9ca3af;
      margin-right: 8px;
    }

    .search-input {
      flex: 1;
      border: none;
      outline: none;
      padding: 12px 0;
      font-size: 14px;
      background: transparent;
    }

    .clear-button {
      background: none;
      border: none;
      color: #9ca3af;
      cursor: pointer;
      padding: 4px;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .notification-icon {
      position: relative;
      cursor: pointer;
      color: #6b7280;
    }

    .notification-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      background: #ef4444;
      color: white;
      border-radius: 50%;
      width: 16px;
      height: 16px;
      font-size: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      overflow: hidden;
      cursor: pointer;
      background: #e5e7eb;
    }

    .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    /* Breadcrumb */
    .breadcrumb-container {
      background: #f8fafc;
      padding: 16px 24px;
      border-bottom: 1px solid #e5e7eb;
    }

    .breadcrumb-content {
      max-width: 1400px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .breadcrumb-link {
      color: #0066cc;
      text-decoration: none;
      font-size: 14px;
    }

    .breadcrumb-separator {
      color: #6b7280;
      font-size: 14px;
    }

    .breadcrumb-current {
      color: #111827;
      font-size: 14px;
      font-weight: 500;
    }

    /* Course Hero */
    .course-hero {
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      padding: 48px 24px;
      position: relative;
      overflow: hidden;
    }

    .hero-content {
      max-width: 1400px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .course-info {
      flex: 1;
      max-width: 600px;
    }

    .course-title {
      font-size: 36px;
      font-weight: 700;
      color: #111827;
      margin: 0 0 16px 0;
      line-height: 1.2;
    }

    .course-subtitle {
      font-size: 18px;
      color: #6b7280;
      margin: 0 0 24px 0;
      line-height: 1.5;
    }

    .author-info {
      margin-bottom: 32px;
      font-size: 14px;
    }

    .created-by {
      color: #6b7280;
    }

    .author-link {
      color: #0066cc;
      text-decoration: none;
      font-weight: 500;
    }

    .enroll-button {
      background: #0066cc;
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      margin-bottom: 16px;
      transition: background 0.2s ease;
    }

    .enroll-button:hover {
      background: #0052a3;
    }

    .enrollment-info {
      font-size: 14px;
      color: #6b7280;
    }

    .course-visual {
      position: relative;
      flex: 1;
      height: 300px;
    }

    .decorative-circles {
      position: relative;
      width: 100%;
      height: 100%;
    }

    .circle {
      position: absolute;
      border: 2px solid #0066cc;
      border-radius: 50%;
      opacity: 0.3;
    }

    .circle-1 {
      width: 200px;
      height: 200px;
      top: 20px;
      right: 100px;
    }

    .circle-2 {
      width: 150px;
      height: 150px;
      bottom: 20px;
      right: 50px;
    }

    /* Course Meta */
    .course-meta-section {
      background: white;
      padding: 24px;
      border-bottom: 1px solid #e5e7eb;
    }

    .meta-content {
      max-width: 1400px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 24px;
    }

    .meta-item {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .meta-label {
      font-size: 12px;
      color: #6b7280;
      font-weight: 500;
    }

    .meta-value {
      font-size: 14px;
      color: #111827;
      font-weight: 600;
    }

    .rating-info {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .rating-value {
      font-size: 14px;
      color: #111827;
      font-weight: 600;
    }

    .star {
      fill: #fbbf24;
      stroke: none;
    }

    .review-count {
      font-size: 12px;
      color: #6b7280;
    }

    /* Course Content */
    .course-content-section {
      background: white;
      min-height: 600px;
    }

    .content-wrapper {
      max-width: 1400px;
      margin: 0 auto;
      padding: 24px;
    }

    .tab-navigation {
      display: flex;
      border-bottom: 1px solid #e5e7eb;
      margin-bottom: 32px;
    }

    .tab-button {
      background: none;
      border: none;
      padding: 12px 24px;
      font-size: 14px;
      color: #6b7280;
      cursor: pointer;
      border-bottom: 2px solid transparent;
      transition: all 0.2s ease;
    }

    .tab-button.active {
      color: #0066cc;
      border-bottom-color: #0066cc;
    }

    .tab-button:hover {
      color: #0066cc;
    }

    .tab-content {
      min-height: 400px;
    }

    .overview-content section {
      margin-bottom: 32px;
    }

    .overview-content h3 {
      font-size: 18px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 16px 0;
    }

    .learning-objectives,
    .requirements-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .learning-objectives li,
    .requirements-list li {
      padding: 8px 0;
      color: #4b5563;
      position: relative;
      padding-left: 20px;
    }

    .learning-objectives li:before,
    .requirements-list li:before {
      content: "•";
      color: #0066cc;
      position: absolute;
      left: 0;
      font-weight: bold;
    }

    .skills-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .skill-tag {
      background: #e0f2fe;
      color: #0369a1;
      padding: 6px 12px;
      border-radius: 16px;
      font-size: 12px;
      font-weight: 500;
    }

    .course-description {
      color: #4b5563;
      line-height: 1.6;
      margin: 0;
    }

    .curriculum-section {
      margin-bottom: 32px;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      overflow: hidden;
    }

    .section-header {
      background: #f9fafb;
      padding: 16px 20px;
      border-bottom: 1px solid #e5e7eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .section-title {
      font-size: 16px;
      font-weight: 600;
      color: #111827;
      margin: 0;
    }

    .section-count {
      font-size: 14px;
      color: #6b7280;
      background: #e5e7eb;
      padding: 4px 8px;
      border-radius: 12px;
    }

    .lecture-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .lecture-item {
      padding: 16px 20px;
      border-bottom: 1px solid #f3f4f6;
    }

    .lecture-item:last-child {
      border-bottom: none;
    }

    .lecture-info {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .lecture-title {
      font-size: 14px;
      color: #374151;
      font-weight: 500;
    }

    .lecture-meta {
      display: flex;
      gap: 12px;
      align-items: center;
    }

    .lecture-type {
      font-size: 12px;
      color: #6b7280;
      background: #f3f4f6;
      padding: 2px 8px;
      border-radius: 4px;
      text-transform: capitalize;
    }

    .lecture-duration {
      font-size: 12px;
      color: #9ca3af;
    }

    .no-curriculum {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    .loading {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 50vh;
      color: #6b7280;
    }

    .reviews-container {
      max-height: 600px;
      overflow-y: auto;
    }

    .review-item {
      background: #f8fafc;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 16px;
      border: 1px solid #e5e7eb;
    }

    .review-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 12px;
    }

    .reviewer-info h4 {
      margin: 0 0 8px 0;
      font-size: 16px;
      font-weight: 600;
      color: #111827;
    }

    .review-rating {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .star-icon {
      display: inline-flex;
    }

    .star-icon svg {
      fill: #d1d5db;
      stroke: none;
    }

    .star-icon svg.filled {
      fill: #fbbf24;
    }

    .rating-number {
      font-size: 14px;
      color: #6b7280;
      font-weight: 500;
    }

    .review-content p {
      margin: 0;
      color: #4b5563;
      font-style: italic;
      line-height: 1.6;
    }

    .no-reviews {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    @media (max-width: 768px) {
      .hero-content {
        flex-direction: column;
        text-align: center;
        gap: 32px;
      }

      .course-title {
        font-size: 28px;
      }

      .meta-content {
        grid-template-columns: repeat(2, 1fr);
      }

      .tab-navigation {
        overflow-x: auto;
      }

      .tab-button {
        white-space: nowrap;
      }
    }
  `]
})
export class CourseDetailComponent implements OnInit {
  course: Course | null = null;
  activeTab: string = 'overview';
  curriculum: any[] = [];
  reviews: any[] = [];
  users: any[] = [];

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private courseService: CourseService
  ) {}

  ngOnInit() {
    const courseId = this.route.snapshot.paramMap.get('id');
    if (courseId) {
      this.loadCourse(parseInt(courseId));
    }
  }

  loadCourse(courseId: number) {
    this.courseService.getCourseById(courseId).subscribe({
      next: (course) => {
        this.course = course;
        // Load curriculum data for this course
        this.loadCurriculum(courseId.toString());
        // Load reviews data for this course
        this.loadReviews(courseId.toString());
      },
      error: (error) => {
        console.error('Error loading course:', error);
        this.router.navigate(['/search']);
      }
    });
  }

  loadCurriculum(courseId: string) {
    this.courseService.getCourseCurriculum(courseId).subscribe({
      next: (curriculum) => {
        this.curriculum = curriculum;
      },
      error: (error) => {
        console.error('Error loading curriculum:', error);
        // If curriculum fails to load, keep empty array
        this.curriculum = [];
      }
    });
  }

  loadReviews(courseId: string) {
    this.courseService.getCourseReviews(courseId).subscribe({
      next: (reviews) => {
        this.reviews = reviews;
        // Load user details for each review
        this.loadUsersForReviews();
      },
      error: (error) => {
        console.error('Error loading reviews:', error);
        // If reviews fail to load, keep empty array
        this.reviews = [];
      }
    });
  }

  loadUsersForReviews() {
    const userIds = [...new Set(this.reviews.map(review => review.userId))];
    userIds.forEach(userId => {
      this.courseService.getUserById(userId).subscribe({
        next: (user) => {
          this.users.push(user);
        },
        error: (error) => {
          console.error('Error loading user:', error);
        }
      });
    });
  }

  setActiveTab(tab: string) {
    this.activeTab = tab;
  }

  formatNumber(num: number): string {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  getAuthorName(): string {
    return this.course?.provider.name || 'Unknown Author';
  }

  getCourseDescription(): string {
    return `Master ${this.course?.title} with this comprehensive course. Learn the fundamentals and advanced techniques used by professionals in the field.`;
  }

  getCurriculum() {
    // Return curriculum from database if available, otherwise return empty array
    return this.curriculum || [];
  }

  getReviews() {
    // Return reviews from database if available, otherwise return empty array
    return this.reviews || [];
  }

  getUserName(userId: number): string {
    const user = this.users.find(u => u.id == userId);
    return user ? user.fullName : 'Anonymous User';
  }

  getStarArray(rating: number): boolean[] {
    return Array(5).fill(false).map((_, i) => i < Math.floor(rating));
  }

  goToDashboard() {
    this.router.navigate(['/dashboard']);
  }

  goToHome() {
    this.router.navigate(['/dashboard']);
  }
}
