# Angular Login System with JSON Database

This Angular application provides a complete authentication system using a JSON database with user management capabilities.

## Features

- **User Authentication**: Login and signup functionality
- **JSON Database**: Uses `json-server` to serve user data from `db.json`
- **Protected Routes**: Dashboard protected by authentication guards
- **User Management**: User profile display and management
- **Responsive Design**: Mobile-friendly interface
- **Form Validation**: Comprehensive form validation for login and signup

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn
- Angular CLI

### Installation

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start the development environment (runs both Angular app and JSON server):
   ```bash
   npm run dev
   ```

   Or run them separately:
   ```bash
   # Terminal 1: Start JSON server
   npm run json-server

   # Terminal 2: Start Angular app
   npm start
   ```

### Access the Application

- **Angular App**: http://localhost:4200
- **JSON Server API**: http://localhost:3000

## Default User Accounts

You can use these existing accounts from `db.json` to test the login functionality:

### Admin Account
- **Username**: `hshimron`
- **Password**: `hashed_password`
- **Role**: Admin

### Author Account
- **Username**: `smaarek`
- **Password**: `hashed_password`
- **Role**: Author

### Learner Accounts
- **Username**: `wwarren`
- **Password**: `hashed_password`
- **Role**: Learner

- **Username**: `jjones`
- **Password**: `hashed_password`
- **Role**: Learner

## Application Structure

```
src/
├── app/
│   ├── components/
│   │   ├── login/           # Login component
│   │   ├── signup/          # Signup component
│   │   └── dashboard/       # Protected dashboard
│   ├── services/
│   │   ├── auth.service.ts  # Authentication logic
│   │   └── user.service.ts  # User data operations
│   ├── models/
│   │   └── user.model.ts    # User interface definitions
│   ├── guards/
│   │   └── auth.guard.ts    # Route protection
│   └── app.routes.ts        # Application routing
```

## API Endpoints

The JSON server provides the following endpoints:

- `GET /users` - Get all users
- `GET /users/:id` - Get user by ID
- `GET /users?username=:username` - Get user by username
- `GET /users?email=:email` - Get user by email
- `POST /users` - Create new user
- `PATCH /users/:id` - Update user
- `DELETE /users/:id` - Delete user

## Features

### Authentication Service
- Login with username/password
- User registration
- Session management with localStorage
- Automatic authentication check on app load

### Route Protection
- Protected routes using Angular Guards
- Automatic redirect to login for unauthenticated users
- Dashboard access only for logged-in users

### User Interface
- Responsive design with modern styling
- Form validation with error messages
- Password visibility toggle
- Loading states and success/error feedback

## Usage

1. **Login**: Navigate to `/login` and use one of the default accounts
2. **Signup**: Navigate to `/signup` to create a new account
3. **Dashboard**: After login, you'll be redirected to a protected dashboard
4. **Logout**: Use the logout button in the dashboard header

## Development

### Building for Production
```bash
npm run build
```

### Running Tests
```bash
npm test
```

### Code Generation
```bash
ng generate component component-name
ng generate service service-name
```

## Security Notes

⚠️ **Important**: This is a demo application. In production:

- Hash passwords before storing
- Use HTTPS for all communications
- Implement proper JWT tokens
- Add rate limiting and other security measures
- Use a real database instead of JSON files

## Customization

- Modify `db.json` to add/edit user data
- Update styling in component CSS files
- Extend user model in `user.model.ts`
- Add new routes in `app.routes.ts`

## Troubleshooting

### Common Issues

1. **Port conflicts**: If ports 4200 or 3000 are in use, update the ports in package.json scripts
2. **CORS issues**: json-server automatically handles CORS for development
3. **Authentication not persisting**: Check if localStorage is enabled in your browser

### Getting Help

If you encounter issues:
1. Check the browser console for errors
2. Verify that both servers are running
3. Ensure all dependencies are installed
4. Check that db.json is valid JSON
