import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { map, catchError, tap, switchMap } from 'rxjs/operators';
import { User, LoginRequest, SignupRequest } from '../models/user.model';
import { UserService } from './user.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();
  private isLoggedInSubject = new BehaviorSubject<boolean>(false);
  public isLoggedIn$ = this.isLoggedInSubject.asObservable();

  constructor(private userService: UserService) {
    // Check if user is already logged in on service initialization
    this.checkStoredAuth();
  }

  private checkStoredAuth(): void {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      const user = JSON.parse(storedUser);
      this.currentUserSubject.next(user);
      this.isLoggedInSubject.next(true);
    }
  }

  login(credentials: LoginRequest): Observable<{ success: boolean; user?: User; message?: string }> {
    return this.userService.getUserByUsername(credentials.username).pipe(
      map(users => {
        if (users.length === 0) {
          return { success: false, message: 'Username not found' };
        }

        const user = users[0];
        // In a real app, you'd hash the password and compare
        // For demo purposes, we're doing a simple comparison
        if (user.password === credentials.password) {
          this.setCurrentUser(user);
          return { success: true, user };
        } else {
          return { success: false, message: 'Invalid password' };
        }
      }),
      catchError(error => {
        console.error('Login error:', error);
        return of({ success: false, message: 'Login failed. Please try again.' });
      })
    );
  }

  signup(signupData: SignupRequest): Observable<{ success: boolean; user?: User; message?: string }> {
    // For simplicity, we'll create the user directly
    // In a real app, you'd check for existing users first
    const newUser: Omit<User, 'id'> = {
      username: signupData.username,
      email: signupData.email,
      password: signupData.password, // In real app, hash this
      fullName: signupData.fullName,
      track: null,
      avatarUrl: `https://i.pravatar.cc/150?u=${signupData.username}`,
      joinDate: new Date().toISOString(),
      role: 'Learner',
      bio: null,
      location: null
    };

    return this.userService.createUser(newUser).pipe(
      map(createdUser => {
        this.setCurrentUser(createdUser);
        return { success: true, user: createdUser, message: 'Account created successfully' };
      }),
      catchError(error => {
        console.error('Signup error:', error);
        return of({ success: false, message: 'Signup failed. Please try again.' });
      })
    );
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
    this.isLoggedInSubject.next(false);
  }

  private setCurrentUser(user: User): void {
    localStorage.setItem('currentUser', JSON.stringify(user));
    this.currentUserSubject.next(user);
    this.isLoggedInSubject.next(true);
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  isAuthenticated(): boolean {
    return this.isLoggedInSubject.value;
  }
}
