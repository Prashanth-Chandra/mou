import { Component, EventEmitter, Output, OnInit, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CourseService } from '../../services/course.service';
import { Course } from '../../models/course.model';
import { debounceTime, distinctUntilChanged, switchMap, catchError } from 'rxjs/operators';
import { Subject, of, Subscription } from 'rxjs';

@Component({
  selector: 'app-search-bar',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="search-container">
      <div class="search-wrapper" [class.active]="isSearchActive">
        <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
          <circle cx="11" cy="11" r="8"></circle>
          <path d="m21 21-4.35-4.35"></path>
        </svg>
        <input 
          #searchInput
          type="text" 
          placeholder="Search Courses" 
          class="search-input"
          [(ngModel)]="searchQuery"
          (input)="onSearchInput($event)"
          (focus)="onSearchFocus()"
          (blur)="onSearchBlur()"
          (keydown)="onKeyDown($event)"
        />
        <button 
          class="clear-button" 
          *ngIf="searchQuery" 
          (click)="clearSearch()"
          type="button"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
      
      <div class="search-dropdown" *ngIf="showDropdown && (searchSuggestions.length > 0 || isLoading || searchQuery)">
        <div class="loading-indicator" *ngIf="isLoading">
          <div class="spinner"></div>
          <span>Searching courses...</span>
        </div>
        
        <div class="no-results" *ngIf="!isLoading && searchQuery && searchSuggestions.length === 0">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor">
            <circle cx="11" cy="11" r="8"></circle>
            <path d="m21 21-4.35-4.35"></path>
          </svg>
          <span>No courses found for "{{ searchQuery }}"</span>
        </div>
        
        <div class="suggestions-list" *ngIf="!isLoading && searchSuggestions.length > 0">
          <div 
            class="suggestion-item"
            *ngFor="let course of searchSuggestions; let i = index"
            [class.highlighted]="i === selectedIndex"
            (click)="selectCourse(course)"
            (mouseenter)="selectedIndex = i"
          >
            <div class="suggestion-title">{{ course.title }}</div>
          </div>
        </div>
        
        <div class="search-footer" *ngIf="!isLoading && searchSuggestions.length > 0">
          <button class="view-all-button" (click)="viewAllResults()">
            View all {{ searchSuggestions.length }} results
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .search-container {
      position: relative;
      width: 100%;
      max-width: 600px;
      flex: 1;
    }

    .search-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      background: white;
      border: 2px solid #e5e7eb;
      border-radius: 8px;
      padding: 0 12px;
      transition: all 0.2s ease;
    }

    .search-wrapper:hover {
      border-color: #d1d5db;
    }

    .search-wrapper.active {
      border-color: #3b82f6;
      box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
    }

    .search-icon {
      color: #9ca3af;
      margin-right: 8px;
    }

    .search-input {
      flex: 1;
      border: none;
      outline: none;
      padding: 12px 0;
      font-size: 14px;
      background: transparent;
    }

    .search-input::placeholder {
      color: #9ca3af;
    }

    .clear-button {
      background: none;
      border: none;
      padding: 4px;
      color: #9ca3af;
      cursor: pointer;
      border-radius: 4px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: color 0.2s ease;
    }

    .clear-button:hover {
      color: #6b7280;
      background: #f3f4f6;
    }

    .search-dropdown {
      position: absolute;
      top: 100%;
      left: 0;
      right: 0;
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      z-index: 1000;
      margin-top: 4px;
      max-height: 400px;
      overflow-y: auto;
    }

    .loading-indicator {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 16px;
      color: #6b7280;
    }

    .spinner {
      width: 20px;
      height: 20px;
      border: 2px solid #e5e7eb;
      border-top-color: #3b82f6;
      border-radius: 50%;
      animation: spin 1s linear infinite;
    }

    @keyframes spin {
      to { transform: rotate(360deg); }
    }

    .no-results {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 8px;
      padding: 24px;
      color: #6b7280;
      text-align: center;
    }

    .suggestions-list {
      padding: 8px 0;
    }

    .suggestion-item {
      display: flex;
      align-items: center;
      padding: 14px 16px;
      cursor: pointer;
      transition: background-color 0.2s ease;
      border-bottom: 1px solid #f3f4f6;
    }

    .suggestion-item:last-child {
      border-bottom: none;
    }

    .suggestion-item:hover,
    .suggestion-item.highlighted {
      background: #f8fafc;
    }

    .suggestion-title {
      font-weight: 400;
      color: #374151;
      font-size: 14px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      flex: 1;
    }

    .suggestion-meta {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 12px;
      color: #6b7280;
      margin-bottom: 4px;
    }

    .separator {
      color: #d1d5db;
    }

    .suggestion-rating {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .stars {
      display: flex;
      gap: 1px;
    }

    .star {
      fill: #d1d5db;
      stroke: none;
    }

    .star.filled {
      fill: #fbbf24;
    }

    .rating-text {
      font-size: 12px;
      color: #6b7280;
      font-weight: 500;
    }

    .search-footer {
      border-top: 1px solid #e5e7eb;
      padding: 12px 16px;
    }

    .view-all-button {
      width: 100%;
      background: none;
      border: none;
      padding: 8px;
      color: #3b82f6;
      font-weight: 500;
      cursor: pointer;
      border-radius: 4px;
      transition: background-color 0.2s ease;
    }

    .view-all-button:hover {
      background: #eff6ff;
    }
  `]
})
export class SearchBarComponent implements OnInit, OnDestroy {
  @Output() courseSelected = new EventEmitter<Course>();
  @Output() searchResults = new EventEmitter<Course[]>();
  @ViewChild('searchInput') searchInput!: ElementRef;

  searchQuery = '';
  searchSuggestions: Course[] = [];
  showDropdown = false;
  isLoading = false;
  selectedIndex = -1;
  isSearchActive = false;

  private searchSubject = new Subject<string>();
  private subscription = new Subscription();

  constructor(private courseService: CourseService) {}

  ngOnInit() {
    this.subscription.add(
      this.searchSubject.pipe(
        debounceTime(300),
        distinctUntilChanged(),
        switchMap(query => {
          if (query.trim().length < 2) {
            return of([]);
          }
          this.isLoading = true;
          return this.courseService.searchCourses(query).pipe(
            catchError(() => of([]))
          );
        })
      ).subscribe(results => {
        this.searchSuggestions = results.slice(0, 6); // Limit to 6 suggestions
        this.isLoading = false;
        this.selectedIndex = -1;
      })
    );
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  onSearchInput(event: any) {
    const query = event.target.value;
    this.searchQuery = query;
    this.searchSubject.next(query);
    this.showDropdown = true;
  }

  onSearchFocus() {
    this.isSearchActive = true;
    if (this.searchQuery) {
      this.showDropdown = true;
    }
  }

  onSearchBlur() {
    this.isSearchActive = false;
    // Delay hiding dropdown to allow for clicks
    setTimeout(() => {
      this.showDropdown = false;
    }, 200);
  }

  onKeyDown(event: KeyboardEvent) {
    if (!this.showDropdown || this.searchSuggestions.length === 0) return;

    switch (event.key) {
      case 'ArrowDown':
        event.preventDefault();
        this.selectedIndex = Math.min(this.selectedIndex + 1, this.searchSuggestions.length - 1);
        break;
      case 'ArrowUp':
        event.preventDefault();
        this.selectedIndex = Math.max(this.selectedIndex - 1, -1);
        break;
      case 'Enter':
        event.preventDefault();
        if (this.selectedIndex >= 0) {
          this.selectCourse(this.searchSuggestions[this.selectedIndex]);
        } else {
          this.viewAllResults();
        }
        break;
      case 'Escape':
        this.showDropdown = false;
        this.searchInput.nativeElement.blur();
        break;
    }
  }

  selectCourse(course: Course) {
    this.courseSelected.emit(course);
    this.showDropdown = false;
    this.searchQuery = course.title;
  }

  clearSearch() {
    this.searchQuery = '';
    this.searchSuggestions = [];
    this.showDropdown = false;
    this.searchInput.nativeElement.focus();
  }

  viewAllResults() {
    this.searchResults.emit(this.searchSuggestions);
    this.showDropdown = false;
  }

  getStarsArray(): number[] {
    return Array(5).fill(0).map((_, i) => i);
  }

  get Math() {
    return Math;
  }
}
