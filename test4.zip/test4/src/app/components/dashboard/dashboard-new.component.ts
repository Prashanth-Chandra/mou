import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { CourseService } from '../../services/course.service';
import { User } from '../../models/user.model';
import { Course, UserEnrollment, DashboardStats } from '../../models/course.model';
import { forkJoin } from 'rxjs';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="dashboard-container">
      <!-- Header -->
      <header class="dashboard-header">
        <div class="header-content">
          <h1 class="product-name">Product Name</h1>
          <div class="search-container">
            <div class="search-wrapper">
              <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <circle cx="11" cy="11" r="8"></circle>
                <path d="m21 21-4.35-4.35"></path>
              </svg>
              <input type="text" placeholder="Search Courses" class="search-input" />
              <svg class="close-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </div>
          </div>
          <div class="header-actions">
            <div class="notification-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              <span class="notification-badge">1</span>
            </div>
            <div class="user-menu" *ngIf="currentUser">
              <img [src]="currentUser.avatarUrl" [alt]="currentUser.fullName" class="user-avatar" (click)="toggleUserMenu()" />
              <div class="user-dropdown" [class.show]="showUserMenu">
                <div class="user-info">
                  <p class="user-name">{{ currentUser.fullName }}</p>
                  <p class="user-email">{{ currentUser.email }}</p>
                </div>
                <hr>
                <button class="dropdown-item">Profile</button>
                <button class="dropdown-item">Settings</button>
                <hr>
                <button class="dropdown-item logout" (click)="logout()">Logout</button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Main Content -->
      <main class="dashboard-main">
        <!-- Stats Cards -->
        <div class="stats-section">
          <div class="stats-card goals">
            <div class="stats-content">
              <div class="stats-text">
                <h3>My Goals</h3>
                <div class="stats-number">{{ dashboardStats.myGoals }}</div>
                <a href="#" class="stats-link">View All</a>
              </div>
              <div class="stats-icon">
                <svg width="60" height="60" viewBox="0 0 100 100" fill="none">
                  <circle cx="50" cy="50" r="45" stroke="#10b981" stroke-width="8" fill="none" opacity="0.2"/>
                  <circle cx="50" cy="50" r="35" stroke="#10b981" stroke-width="6" fill="none" opacity="0.4"/>
                  <circle cx="50" cy="50" r="25" fill="#10b981" opacity="0.6"/>
                </svg>
              </div>
            </div>
          </div>

          <div class="stats-card courses">
            <div class="stats-content">
              <div class="stats-text">
                <h3>Enrolled Courses</h3>
                <div class="stats-number">{{ dashboardStats.enrolledCourses }}</div>
                <a href="#" class="stats-link">View All</a>
              </div>
              <div class="stats-icon">
                <svg width="60" height="60" viewBox="0 0 100 100" fill="none">
                  <rect x="20" y="30" width="60" height="40" rx="4" stroke="#3b82f6" stroke-width="4" fill="none"/>
                  <rect x="25" y="35" width="50" height="30" fill="#3b82f6" opacity="0.3"/>
                  <rect x="30" y="20" width="40" height="8" fill="#3b82f6" opacity="0.6"/>
                </svg>
              </div>
            </div>
          </div>

          <div class="stats-card certificates">
            <div class="stats-content">
              <div class="stats-text">
                <h3>Certificates Earned</h3>
                <div class="stats-number">{{ dashboardStats.certificatesEarned }}</div>
                <a href="#" class="stats-link">Download</a>
              </div>
              <div class="stats-icon">
                <svg width="60" height="60" viewBox="0 0 100 100" fill="none">
                  <rect x="25" y="15" width="50" height="70" rx="4" stroke="#f59e0b" stroke-width="4" fill="none"/>
                  <path d="M40 75 L50 85 L60 75" stroke="#f59e0b" stroke-width="3" fill="none"/>
                  <circle cx="50" cy="40" r="12" fill="#f59e0b" opacity="0.3"/>
                  <path d="M45 40 L48 43 L55 36" stroke="#f59e0b" stroke-width="2" fill="none"/>
                </svg>
              </div>
            </div>
          </div>
        </div>

        <!-- Last Viewed Courses -->
        <section class="courses-section">
          <div class="section-header">
            <h2>Last Viewed Courses</h2>
          </div>
          <div class="courses-grid">
            <div class="course-card" *ngFor="let course of enrolledCourses">
              <div class="course-image">
                <img [src]="course.thumbnailUrl" [alt]="course.title" />
                <div class="progress-badge" [attr.data-progress]="getProgressText(course.id)">
                  {{ getProgressText(course.id) }}
                </div>
              </div>
              <div class="course-content">
                <h3 class="course-title">{{ course.title }}</h3>
                <div class="course-provider">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                  </svg>
                  <span>LEARNING</span>
                </div>
                <div class="course-rating">
                  <span class="rating-number">{{ course.rating }}</span>
                  <div class="stars">
                    <span class="star">★</span>
                  </div>
                  <span class="review-count">({{ course.reviewCount | number }} reviews | {{ course.enrollmentCount }} Enrolled)</span>
                </div>
                <div class="course-meta">
                  <span class="difficulty">{{ course.difficulty }}</span>
                  <span class="duration">{{ course.durationText }}</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- Newly Launched -->
        <section class="courses-section">
          <div class="section-header">
            <h2>Newly Launched</h2>
          </div>
          <div class="courses-grid">
            <div class="course-card" *ngFor="let course of newCourses">
              <div class="course-image">
                <img [src]="course.thumbnailUrl" [alt]="course.title" />
              </div>
              <div class="course-content">
                <h3 class="course-title">{{ course.title }}</h3>
                <div class="course-provider">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                  </svg>
                  <span>LEARNING</span>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  `,
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  currentUser: User | null = null;
  showUserMenu = false;
  dashboardStats: DashboardStats = {
    myGoals: 3,
    enrolledCourses: 8,
    certificatesEarned: 2
  };
  
  allCourses: Course[] = [];
  enrolledCourses: Course[] = [];
  newCourses: Course[] = [];
  userEnrollments: UserEnrollment[] = [];

  constructor(
    private authService: AuthService,
    private courseService: CourseService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadDashboardData();
      }
    });
  }

  loadDashboardData(): void {
    if (!this.currentUser) return;

    forkJoin({
      courses: this.courseService.getAllCourses(),
      enrollments: this.courseService.getAllUserEnrollments()
    }).subscribe({
      next: (data) => {
        this.allCourses = data.courses;
        const userEnrollments = data.enrollments[this.currentUser!.id.toString()] || [];
        this.userEnrollments = userEnrollments;
        
        // Get enrolled courses
        this.enrolledCourses = this.allCourses.filter(course => 
          userEnrollments.some(enrollment => enrollment.courseId === course.id)
        );
        
        // Get newly launched courses (not enrolled)
        this.newCourses = this.allCourses.filter(course => 
          !userEnrollments.some(enrollment => enrollment.courseId === course.id)
        );

        // Update stats
        this.dashboardStats.enrolledCourses = this.enrolledCourses.length;
      },
      error: (error) => {
        console.error('Error loading dashboard data:', error);
      }
    });
  }

  getProgressText(courseId: number): string {
    const enrollment = this.userEnrollments.find(e => e.courseId === courseId);
    if (!enrollment) return '';
    
    if (enrollment.progressPercent === 100) return '100% Complete';
    if (enrollment.progressPercent >= 80) return `${enrollment.progressPercent}% Complete`;
    if (enrollment.progressPercent >= 60) return `${enrollment.progressPercent}% Complete`;
    if (enrollment.progressPercent >= 20) return `${enrollment.progressPercent}% Complete`;
    return `${enrollment.progressPercent}% Complete`;
  }

  getStars(rating: number): number[] {
    return Array(Math.floor(rating)).fill(0);
  }

  toggleUserMenu(): void {
    this.showUserMenu = !this.showUserMenu;
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}
