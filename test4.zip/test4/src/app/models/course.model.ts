export interface Course {
  id: number;
  title: string;
  subtitle: string;
  authorId: number;
  provider: {
    name: string;
    logoUrl: string;
  };
  thumbnailUrl: string;
  rating: number;
  reviewCount: number;
  enrollmentCount: number;
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  durationText: string;
  skills: string[];
  whatYoullLearn: string[];
  requirements: string[];
  status: string;
  publishedDate: string;
}

export interface UserEnrollment {
  courseId: number;
  progressPercent: number;
}

export interface DashboardStats {
  myGoals: number;
  enrolledCourses: number;
  certificatesEarned: number;
}
