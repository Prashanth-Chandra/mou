import { Component, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Subscription } from 'rxjs';
import { CourseService } from '../../services/course.service';
import { AuthService } from '../../services/auth.service';
import { Course } from '../../models/course.model';
import { User } from '../../models/user.model';
import { UserProgress } from '../../models/enrollment.model';
import { SearchBarComponent } from '../search-bar/search-bar.component';

interface Lecture {
  id: string;
  title: string;
  duration: string;
  videoUrl?: string;
  isCompleted: boolean;
  isLocked: boolean;
}

interface Section {
  id: string;
  title: string;
  duration: string;
  lectures: Lecture[];
  isExpanded: boolean;
}

@Component({
  selector: 'app-course-learn',
  standalone: true,
  imports: [CommonModule, SearchBarComponent],
  template: `
    <div class="learn-container" *ngIf="course">
      <!-- Header -->
      <header class="dashboard-header">
        <div class="header-content">
          <h1 class="product-name">Product Name</h1>
          <app-search-bar 
            (courseSelected)="onCourseSelected($event)"
            (searchResults)="onSearchResults($event)"
          ></app-search-bar>
          <div class="header-actions">
            <div class="notification-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              <span class="notification-badge">1</span>
            </div>
            <div class="user-menu" *ngIf="currentUser">
              <img [src]="currentUser.avatarUrl" [alt]="currentUser.fullName" class="user-avatar" (click)="toggleUserMenu()" />
              <div class="user-dropdown" [class.show]="showUserMenu">
                <div class="user-info">
                  <div class="user-avatar-large">
                    <img [src]="currentUser.avatarUrl" [alt]="currentUser.fullName" class="dropdown-avatar" />
                  </div>
                  <div class="user-details">
                    <p class="user-name">{{ currentUser.fullName }}</p>
                    <p class="user-role">{{ currentUser.track || currentUser.role }}</p>
                  </div>
                </div>
                <hr>
                <button class="dropdown-item" (click)="navigateToProfile()">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                  </svg>
                  My Profile
                </button>
                <button class="dropdown-item" (click)="navigateToAdminConsole()" *ngIf="currentUser.role === 'Admin'">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
                    <line x1="9" y1="9" x2="9" y2="15"></line>
                    <line x1="15" y1="9" x2="15" y2="15"></line>
                  </svg>
                  Admin Console
                </button>
                <button class="dropdown-item" (click)="navigateToMyCourses()">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                  </svg>
                  My Courses
                </button>
                <button class="dropdown-item" (click)="navigateToBlog()">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                  </svg>
                  Blog
                </button>
                <hr>
                <button class="dropdown-item logout" (click)="logout()">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path>
                    <polyline points="16,17 21,12 16,7"></polyline>
                    <line x1="21" y1="12" x2="9" y2="12"></line>
                  </svg>
                  Log Out
                </button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Breadcrumb -->
      <nav class="breadcrumb">
        <span class="breadcrumb-item" (click)="goHome()">Home</span>
        <span class="breadcrumb-separator">/</span>
        <span class="breadcrumb-item" (click)="goToCourse()">{{ course.title }}</span>
      </nav>

      <!-- Main Content -->
      <div class="main-content">
        <!-- Left Panel - Video Player -->
        <div class="video-panel">
          <div class="video-container">
            <iframe 
              #videoPlayer
              class="video-player"
              [src]="getYouTubeEmbedUrl(currentLecture?.videoUrl)"
              frameborder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              referrerpolicy="strict-origin-when-cross-origin"
              allowfullscreen
              (load)="onVideoLoaded()"
              (error)="onVideoError($event)">
            </iframe>

            <!-- Placeholder is not needed since default URL is always shown -->
            <div class="video-loading" *ngIf="!videoLoaded">
              <div class="loading-spinner">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                  <path d="M21 12a9 9 0 11-6.219-8.56"></path>
                </svg>
              </div>
              <p>Loading video...</p>
            </div>
          </div>


          
          <!-- Video Controls -->
          <div class="video-controls">
            <div class="control-buttons">
              <button class="control-btn" (click)="previousLecture()" [disabled]="!hasPreviousLecture()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <polygon points="19,20 9,12 19,4"></polygon>
                  <line x1="5" y1="19" x2="5" y2="5"></line>
                </svg>
              </button>
              <button class="control-btn next-btn" (click)="nextLecture()" [disabled]="!hasNextLecture()">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <polygon points="5,4 15,12 5,20"></polygon>
                  <line x1="19" y1="5" x2="19" y2="19"></line>
                </svg>
              </button>
            </div>
            <div class="completion-controls">
              <button 
                class="complete-btn" 
                *ngIf="currentLecture && !currentLecture.isCompleted"
                (click)="markLectureComplete()">
                Mark as Complete
              </button>
              <span 
                class="completed-indicator"
                *ngIf="currentLecture && currentLecture.isCompleted">
                ✓ Completed
              </span>
            </div>
          </div>

          <!-- Lecture Info -->
          <div class="lecture-info" *ngIf="currentLecture">
            <h2 class="lecture-title">{{ currentLecture.title }}</h2>
            <p class="lecture-description">
              Learn the fundamentals and advanced techniques in this comprehensive lecture.
            </p>
          </div>

          <!-- Tabs -->
          <div class="content-tabs">
            <button 
              class="tab-button" 
              [class.active]="activeTab === 'overview'"
              (click)="setActiveTab('overview')">
              Overview
            </button>
            <button 
              class="tab-button" 
              [class.active]="activeTab === 'author'"
              (click)="setActiveTab('author')">
              Author Details
            </button>
            <button 
              class="tab-button" 
              [class.active]="activeTab === 'testimonials'"
              (click)="setActiveTab('testimonials')">
              Testimonials
            </button>
          </div>

          <!-- Tab Content -->
          <div class="tab-content">
            <div *ngIf="activeTab === 'overview'" class="tab-panel">
              <h3>What you'll learn</h3>
              <ul class="learning-objectives">
                <li *ngFor="let objective of course.whatYoullLearn">{{ objective }}</li>
              </ul>
              
              <h3>Skills you'll gain</h3>
              <div class="skills-list">
                <span *ngFor="let skill of course.skills" class="skill-tag">{{ skill }}</span>
              </div>
            </div>
            
            <div *ngIf="activeTab === 'author'" class="tab-panel">
              <h3>About the Instructor</h3>
              <p>Detailed information about the course instructor and their expertise.</p>
            </div>
            
            <div *ngIf="activeTab === 'testimonials'" class="tab-panel">
              <h3>What Students Say</h3>
              <p>Student reviews and testimonials about this course.</p>
            </div>
          </div>
        </div>

        <!-- Right Panel - Course Content -->
        <div class="content-panel">
          <div class="content-header">
            <h3>Course Content</h3>
            <div class="content-stats">
              <span>{{ getTotalSections() }} sections • {{ getTotalLectures() }} lectures • {{ getTotalDuration() }}</span>
            </div>
          </div>

          <div class="content-list">
            <div *ngFor="let section of sections; trackBy: trackBySection" class="content-section">
              <div class="section-header" (click)="toggleSection(section.id)">
                <div class="section-info">
                  <h4 class="section-title">{{ section.title }}</h4>
                  <span class="section-meta">{{ section.lectures.length }} lectures • {{ section.duration }}</span>
                </div>
                <button class="section-toggle">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" 
                       [class.rotated]="section.isExpanded">
                    <polyline points="6,9 12,15 18,9"></polyline>
                  </svg>
                </button>
              </div>
              
              <div class="lecture-list" *ngIf="section.isExpanded">
                <div *ngFor="let lecture of section.lectures; trackBy: trackByLecture" 
                     class="lecture-item"
                     [class.active]="currentLecture?.id === lecture.id"
                     [class.completed]="lecture.isCompleted"
                     [class.locked]="lecture.isLocked"
                     (click)="selectLecture(lecture)">
                  <div class="lecture-icon">
                    <svg *ngIf="lecture.isCompleted" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" class="check-icon">
                      <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                    </svg>
                    <svg *ngIf="!lecture.isCompleted && !lecture.isLocked" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" class="play-icon">
                      <polygon points="5,3 19,12 5,21"></polygon>
                    </svg>
                    <svg *ngIf="lecture.isLocked" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" class="lock-icon">
                      <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                      <circle cx="12" cy="7" r="4"></circle>
                    </svg>
                  </div>
                  <div class="lecture-content">
                    <span class="lecture-title">{{ lecture.title }}</span>
                    <span class="lecture-duration">{{ lecture.duration }}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div *ngIf="!course" class="loading">
      <p>Loading course...</p>
    </div>
  `,
  styles: [`
    .learn-container {
      min-height: 100vh;
      background: #f8fafc;
      display: flex;
      flex-direction: column;
    }

    /* Header Styles */
    .dashboard-header {
      background: white;
      border-bottom: 1px solid #e5e7eb;
      padding: 0 24px;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .learn-header {
      background: white;
      border-bottom: 1px solid #e5e7eb;
      padding: 0 24px;
      position: sticky;
      top: 0;
      z-index: 100;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      max-width: 1400px;
      margin: 0 auto;
      height: 64px;
    }

    .product-name {
      font-size: 20px;
      font-weight: 600;
      color: #111827;
      margin: 0;
    }

    .search-wrapper {
      position: relative;
      flex: 1;
      max-width: 400px;
      margin: 0 40px;
    }

    .search-input {
      width: 100%;
      padding: 8px 40px 8px 40px;
      border: 1px solid #d1d5db;
      border-radius: 8px;
      font-size: 14px;
      background: #f9fafb;
    }

    .search-icon {
      position: absolute;
      left: 12px;
      top: 50%;
      transform: translateY(-50%);
      color: #6b7280;
    }

    .clear-button {
      position: absolute;
      right: 8px;
      top: 50%;
      transform: translateY(-50%);
      background: none;
      border: none;
      cursor: pointer;
      color: #6b7280;
      padding: 4px;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .notification-icon {
      color: #6b7280;
      cursor: pointer;
    }

    .notification-icon {
      position: relative;
      color: #6b7280;
      cursor: pointer;
      padding: 8px;
      border-radius: 50%;
      transition: all 0.2s ease;
    }

    .notification-icon:hover {
      background: #f3f4f6;
      color: #111827;
    }

    .notification-badge {
      position: absolute;
      top: 4px;
      right: 4px;
      background: #ef4444;
      color: white;
      border-radius: 50%;
      width: 16px;
      height: 16px;
      font-size: 10px;
      font-weight: 600;
      display: flex;
      align-items: center;
      justify-content: center;
      border: 2px solid white;
    }

    .user-menu {
      position: relative;
    }

    .user-avatar {
      width: 36px;
      height: 36px;
      border-radius: 50%;
      cursor: pointer;
      border: 2px solid #e5e7eb;
      transition: border-color 0.2s ease;
    }

    .user-avatar:hover {
      border-color: #3b82f6;
    }

    .user-avatar img {
      width: 100%;
      height: 100%;
      border-radius: 50%;
      object-fit: cover;
    }

    .user-dropdown {
      position: absolute;
      top: 100%;
      right: 0;
      background: white;
      border: 1px solid #e5e7eb;
      border-radius: 8px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
      min-width: 240px;
      opacity: 0;
      visibility: hidden;
      transform: translateY(-10px);
      transition: all 0.3s ease;
      z-index: 1000;
    }

    .user-dropdown.show {
      opacity: 1;
      visibility: visible;
      transform: translateY(0);
    }

    .user-info {
      display: flex;
      align-items: center;
      padding: 16px;
      gap: 12px;
    }

    .user-avatar-large {
      flex-shrink: 0;
    }

    .dropdown-avatar {
      width: 48px;
      height: 48px;
      border-radius: 50%;
      border: 2px solid #e5e7eb;
    }

    .user-details {
      flex: 1;
      min-width: 0;
    }

    .user-name {
      font-weight: 600;
      color: #111827;
      margin: 0 0 4px 0;
      font-size: 14px;
    }

    .user-role {
      color: #6b7280;
      margin: 0;
      font-size: 12px;
    }

    .user-dropdown hr {
      margin: 0;
      border: none;
      border-top: 1px solid #e5e7eb;
    }

    .dropdown-item {
      width: 100%;
      padding: 12px 16px;
      border: none;
      background: none;
      text-align: left;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 12px;
      font-size: 14px;
      color: #374151;
      transition: background 0.2s ease;
    }

    .dropdown-item:hover {
      background: #f3f4f6;
    }

    .dropdown-item.logout {
      color: #dc2626;
    }

    .dropdown-item.logout:hover {
      background: #fef2f2;
    }

    .dropdown-item svg {
      flex-shrink: 0;
    }

    .user-avatar img {
      width: 32px;
      height: 32px;
      border-radius: 50%;
    }

    /* Breadcrumb */
    .breadcrumb {
      padding: 12px 24px;
      background: white;
      border-bottom: 1px solid #e5e7eb;
      font-size: 14px;
      color: #6b7280;
    }

    .breadcrumb-item {
      cursor: pointer;
      color: #3b82f6;
    }

    .breadcrumb-item:hover {
      text-decoration: underline;
    }

    .breadcrumb-separator {
      margin: 0 8px;
    }

    /* Main Content */
    .main-content {
      display: flex;
      flex: 1;
      max-width: 1400px;
      margin: 0 auto;
      width: 100%;
    }

    /* Video Panel */
    .video-panel {
      flex: 1;
      background: white;
      padding: 24px;
      margin: 24px 0 24px 24px;
      border-radius: 8px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
    }

    .video-container {
      position: relative;
      width: 100%;
      aspect-ratio: 16/9;
      background: #000;
      border-radius: 8px;
      overflow: hidden;
      margin-bottom: 16px;
    }

    .video-player {
      width: 100%;
      height: 100%;
      border: none;
    }

    .video-overlay {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    }

    .video-placeholder {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      color: #6b7280;
    }

    .placeholder-content {
      text-align: center;
    }

    .placeholder-content h3 {
      margin: 16px 0 8px 0;
      font-size: 18px;
      font-weight: 600;
      color: #374151;
    }

    .placeholder-content p {
      margin: 0;
      font-size: 14px;
      color: #6b7280;
    }

    .video-loading {
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.8);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      color: white;
      z-index: 10;
    }

    .loading-spinner {
      animation: spin 1s linear infinite;
      margin-bottom: 12px;
    }

    @keyframes spin {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }

    .video-loading p {
      margin: 0;
      font-size: 14px;
    }

    .play-button {
      background: rgba(255, 255, 255, 0.2);
      border-radius: 50%;
      padding: 16px;
      transition: all 0.3s ease;
    }

    .play-button:hover {
      background: rgba(255, 255, 255, 0.3);
      transform: scale(1.1);
    }

    .video-controls {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 24px;
    }

    .control-buttons {
      display: flex;
      gap: 8px;
    }

    .control-btn {
      background: #f3f4f6;
      border: 1px solid #d1d5db;
      border-radius: 6px;
      padding: 8px;
      cursor: pointer;
      color: #374151;
      transition: all 0.2s ease;
    }

    .control-btn:hover:not(:disabled) {
      background: #e5e7eb;
    }

    .control-btn:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    .next-btn {
      background: #3b82f6;
      color: white;
      border-color: #3b82f6;
    }

    .next-btn:hover:not(:disabled) {
      background: #2563eb;
    }

    .completion-controls {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .complete-btn {
      background: #10b981;
      color: white;
      border: none;
      padding: 8px 16px;
      border-radius: 6px;
      font-size: 14px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .complete-btn:hover {
      background: #059669;
    }

    .completed-indicator {
      color: #10b981;
      font-weight: 600;
      font-size: 14px;
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .lecture-info {
      margin-bottom: 24px;
      padding-bottom: 24px;
      border-bottom: 1px solid #e5e7eb;
    }

    .lecture-title {
      font-size: 24px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 8px 0;
    }

    .lecture-description {
      color: #6b7280;
      margin: 0;
      line-height: 1.5;
    }

    /* Tabs */
    .content-tabs {
      display: flex;
      border-bottom: 1px solid #e5e7eb;
      margin-bottom: 24px;
    }

    .tab-button {
      padding: 12px 16px;
      background: none;
      border: none;
      border-bottom: 2px solid transparent;
      cursor: pointer;
      font-weight: 500;
      color: #6b7280;
      transition: all 0.2s ease;
    }

    .tab-button.active {
      color: #3b82f6;
      border-bottom-color: #3b82f6;
    }

    .tab-button:hover {
      color: #374151;
    }

    .tab-content {
      min-height: 200px;
    }

    .tab-panel h3 {
      font-size: 18px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 16px 0;
    }

    .learning-objectives {
      margin: 0 0 24px 0;
      padding-left: 20px;
    }

    .learning-objectives li {
      margin-bottom: 8px;
      color: #374151;
      line-height: 1.5;
    }

    .skills-list {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .skill-tag {
      background: #f3f4f6;
      color: #374151;
      padding: 4px 12px;
      border-radius: 20px;
      font-size: 14px;
      font-weight: 500;
    }

    /* Content Panel */
    .content-panel {
      width: 400px;
      background: white;
      margin: 24px 24px 24px 0;
      border-radius: 8px;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      display: flex;
      flex-direction: column;
    }

    .content-header {
      padding: 24px 24px 16px 24px;
      border-bottom: 1px solid #e5e7eb;
    }

    .content-header h3 {
      font-size: 18px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 8px 0;
    }

    .content-stats {
      font-size: 14px;
      color: #6b7280;
    }

    .content-list {
      flex: 1;
      overflow-y: auto;
    }

    .content-section {
      border-bottom: 1px solid #f3f4f6;
    }

    .section-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 16px 24px;
      cursor: pointer;
      transition: background-color 0.2s ease;
    }

    .section-header:hover {
      background: #f9fafb;
    }

    .section-info {
      flex: 1;
    }

    .section-title {
      font-size: 15px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 4px 0;
    }

    .section-meta {
      font-size: 13px;
      color: #6b7280;
    }

    .section-toggle {
      background: none;
      border: none;
      cursor: pointer;
      color: #6b7280;
      padding: 4px;
      transition: transform 0.2s ease;
    }

    .section-toggle svg.rotated {
      transform: rotate(180deg);
    }

    .lecture-list {
      background: #f9fafb;
    }

    .lecture-item {
      display: flex;
      align-items: center;
      padding: 12px 24px 12px 48px;
      cursor: pointer;
      transition: all 0.2s ease;
      border-left: 3px solid transparent;
    }

    .lecture-item:hover {
      background: #f3f4f6;
    }

    .lecture-item.active {
      background: #eff6ff;
      border-left-color: #3b82f6;
    }

    .lecture-item.completed .lecture-icon {
      color: #10b981;
    }

    .lecture-item.locked {
      opacity: 0.6;
      cursor: not-allowed;
    }

    .lecture-icon {
      margin-right: 12px;
      color: #6b7280;
    }

    .check-icon {
      color: #10b981;
    }

    .play-icon {
      color: #3b82f6;
    }

    .lock-icon {
      color: #9ca3af;
    }

    .lecture-content {
      flex: 1;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .lecture-title {
      font-size: 14px;
      color: #374151;
      font-weight: 500;
    }

    .lecture-duration {
      font-size: 13px;
      color: #6b7280;
    }

    .loading {
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 50vh;
      color: #6b7280;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
      .main-content {
        flex-direction: column;
      }

      .video-panel {
        margin: 16px;
      }

      .content-panel {
        width: auto;
        margin: 0 16px 16px 16px;
      }

      .header-content {
        padding: 0 16px;
      }

      .search-wrapper {
        margin: 0 20px;
        max-width: 300px;
      }
    }

    @media (max-width: 768px) {
      .content-tabs {
        overflow-x: auto;
      }

      .tab-button {
        white-space: nowrap;
        padding: 8px 12px;
        font-size: 14px;
      }

      .lecture-title {
        font-size: 20px;
      }

      .content-header {
        padding: 16px;
      }

      .section-header {
        padding: 12px 16px;
      }

      .lecture-item {
        padding: 10px 16px 10px 32px;
      }
    }
  `]
})
export class CourseLearnComponent implements OnInit, OnDestroy {
  course: Course | null = null;
  sections: Section[] = [];
  currentLecture: Lecture | null = null;
  activeTab: string = 'overview';
  isPlaying: boolean = false;
  currentTime: string = '0:00';
  duration: string = '0:00';
  progressPercentage: number = 0;
  userProgress: UserProgress[] = [];
  currentUserId: string = '1'; // Hardcoded for demo - should come from auth service
  
  // Header-related properties
  currentUser: User | null = null;
  showUserMenu: boolean = false;
  videoLoaded: boolean = false;
  videoError: boolean = false;
  
  private routeSubscription: Subscription = new Subscription();

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private courseService: CourseService,
    private authService: AuthService,
    private sanitizer: DomSanitizer
  ) {}

  ngOnInit() {
    // Initialize current user
    this.currentUser = {
      id: 1,
      username: 'hshimron',
      email: 'harry.shimron@example.com',
      password: 'hashed_password',
      fullName: 'Harry Shimron',
      track: 'DC Software Engineer II',
      avatarUrl: 'https://i.pravatar.cc/150?u=hshimron',
      joinDate: '2021-08-14T00:00:00.000Z',
      role: 'Admin',
      bio: 'Passionate learner and developer',
      location: 'Bangalore, India'
    };

    this.routeSubscription = this.route.paramMap.subscribe(params => {
      const courseId = params.get('courseId');
      const lectureId = params.get('lectureId');
      
      if (courseId) {
        this.loadCourse(parseInt(courseId));
        this.loadCurriculum(courseId, lectureId);
        this.loadUserProgress(courseId);
      }
    });
  }

  ngOnDestroy() {
    this.routeSubscription.unsubscribe();
  }

  loadCourse(courseId: number) {
    this.courseService.getCourseById(courseId).subscribe({
      next: (course) => {
        this.course = course;
      },
      error: (error) => {
        console.error('Error loading course:', error);
      }
    });
  }

  loadUserProgress(courseId: string) {
    this.courseService.getUserProgress(this.currentUserId, courseId).subscribe({
      next: (progress) => {
        this.userProgress = progress;
        this.updateLectureCompletionStatus();
      },
      error: (error) => {
        console.error('Error loading user progress:', error);
      }
    });
  }

  updateLectureCompletionStatus() {
    // Update the completion status of lectures based on user progress
    this.sections.forEach(section => {
      section.lectures.forEach(lecture => {
        const progress = this.userProgress.find(p => p.lectureId === lecture.id);
        lecture.isCompleted = progress?.completed || false;
      });
    });
  }

  loadCurriculum(courseId: string, lectureId?: string | null) {
    this.courseService.getCourseCurriculum(courseId).subscribe({
      next: (curriculum) => {
        // Transform curriculum data to sections format
        this.sections = curriculum.map(section => ({
          id: section.id,
          title: section.title,
          duration: this.calculateSectionDuration(section.lectures),
          isExpanded: true, // Start with all sections expanded
          lectures: section.lectures.map((lecture: any, index: number) => ({
            id: lecture.id,
            title: lecture.title,
            duration: `${lecture.durationMinutes}min`,
            videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', // Sample working YouTube video
            isCompleted: false, // Will be updated when progress is loaded
            isLocked: false // No locked lectures for demo
          }))
        }));

        // Update completion status if progress is already loaded
        if (this.userProgress.length > 0) {
          this.updateLectureCompletionStatus();
        }

        // Set current lecture
        if (lectureId) {
          this.setCurrentLectureById(lectureId);
        } else {
          // Default to first lecture
          this.setFirstLecture();
        }
      },
      error: (error) => {
        console.error('Error loading curriculum:', error);
      }
    });
  }

  setCurrentLectureById(lectureId: string) {
    for (const section of this.sections) {
      const lecture = section.lectures.find(l => l.id === lectureId);
      if (lecture) {
        this.currentLecture = lecture;
        break;
      }
    }
  }

  setFirstLecture() {
    if (this.sections.length > 0 && this.sections[0].lectures.length > 0) {
      this.currentLecture = this.sections[0].lectures[0];
    }
  }

  selectLecture(lecture: Lecture) {
    if (lecture.isLocked) return;
    
    this.currentLecture = lecture;
    this.videoLoaded = false; // Reset video loading state
    this.videoError = false; // Reset error state
    
    // Update URL to reflect current lecture
    if (this.course) {
      this.router.navigate(['/learn', this.course.id, 'lecture', lecture.id]);
    }
  }

  toggleSection(sectionId: string) {
    const section = this.sections.find(s => s.id === sectionId);
    if (section) {
      section.isExpanded = !section.isExpanded;
    }
  }

  setActiveTab(tab: string) {
    this.activeTab = tab;
  }

  // Video control methods
  getYouTubeEmbedUrl(url: string | undefined): SafeResourceUrl {
    // Use default video if no URL provided
    const videoUrl = url || 'https://www.youtube.com/watch?v=dQw4w9WgXcQ';
    
    // Extract video ID from YouTube URL
    const videoId = this.extractYouTubeVideoId(videoUrl);
    if (videoId) {
      const embedUrl = `https://www.youtube.com/embed/${videoId}?enablejsapi=1&origin=${window.location.origin}&rel=0&modestbranding=1`;
      return this.sanitizer.bypassSecurityTrustResourceUrl(embedUrl);
    }
    
    // If it's already an embed URL, use it directly
    if (videoUrl.includes('embed')) {
      return this.sanitizer.bypassSecurityTrustResourceUrl(videoUrl);
    }
    
    return this.sanitizer.bypassSecurityTrustResourceUrl(videoUrl);
  }

  private extractYouTubeVideoId(url: string): string | null {
    // Handle various YouTube URL formats
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)/,
      /youtube\.com\/v\/([^&\n?#]+)/,
      /youtube\.com\/user\/[^\/]+#p\/[a-u]\/\d+\/([^&\n?#]+)/
    ];
    
    for (const pattern of patterns) {
      const match = url.match(pattern);
      if (match && match[1] && match[1].length === 11) {
        return match[1];
      }
    }
    
    return null;
  }

  markLectureComplete() {
    if (this.currentLecture && this.course) {
      this.courseService.markLectureAsComplete(
        this.currentUserId, 
        this.course.id.toString(), 
        this.currentLecture.id
      ).subscribe({
        next: (progress) => {
          this.currentLecture!.isCompleted = true;
          console.log(`Lecture "${this.currentLecture!.title}" marked as complete`);
          
          // Update enrollment progress
          this.updateEnrollmentProgress();
        },
        error: (error) => {
          console.error('Error marking lecture as complete:', error);
        }
      });
    }
  }

  updateEnrollmentProgress() {
    if (this.course) {
      this.courseService.updateEnrollmentProgress(
        this.currentUserId, 
        this.course.id.toString()
      ).subscribe({
        next: (enrollment) => {
          console.log('Enrollment progress updated:', enrollment);
        },
        error: (error) => {
          console.error('Error updating enrollment progress:', error);
        }
      });
    }
  }

  togglePlayPause() {
    // For YouTube iframe, we can't directly control playback
    // This method is kept for potential future use
    console.log('Play/Pause not available for YouTube videos');
  }

  previousLecture() {
    const currentIndex = this.getCurrentLectureIndex();
    if (currentIndex > 0) {
      const allLectures = this.getAllLectures();
      this.selectLecture(allLectures[currentIndex - 1]);
    }
  }

  nextLecture() {
    const currentIndex = this.getCurrentLectureIndex();
    const allLectures = this.getAllLectures();
    if (currentIndex < allLectures.length - 1) {
      this.selectLecture(allLectures[currentIndex + 1]);
    }
  }

  hasPreviousLecture(): boolean {
    return this.getCurrentLectureIndex() > 0;
  }

  hasNextLecture(): boolean {
    const currentIndex = this.getCurrentLectureIndex();
    const allLectures = this.getAllLectures();
    return currentIndex < allLectures.length - 1;
  }

  private getCurrentLectureIndex(): number {
    const allLectures = this.getAllLectures();
    return allLectures.findIndex(l => l.id === this.currentLecture?.id);
  }

  private getAllLectures(): Lecture[] {
    return this.sections.flatMap(s => s.lectures);
  }

  onTimeUpdate(event: any) {
    // For YouTube iframe, we can't directly track time updates
    // This would require YouTube API integration for full functionality
  }

  onVideoEnded() {
    // For YouTube iframe, this would need to be triggered via YouTube API
    // For now, users need to manually mark lectures as complete
    console.log('Video ended - mark as complete manually');
  }

  private formatTime(seconds: number): string {
    if (isNaN(seconds)) return '0:00';
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = Math.floor(seconds % 60);
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  }

  // Utility methods
  getTotalSections(): number {
    return this.sections.length;
  }

  getTotalLectures(): number {
    return this.sections.reduce((total, section) => total + section.lectures.length, 0);
  }

  getTotalDuration(): string {
    // Calculate total duration from all lectures
    return "12h 30m"; // Placeholder
  }

  calculateSectionDuration(lectures: any[]): string {
    const totalMinutes = lectures.reduce((total, lecture) => total + (lecture.durationMinutes || 0), 0);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  }

  trackBySection(index: number, section: Section): string {
    return section.id;
  }

  trackByLecture(index: number, lecture: Lecture): string {
    return lecture.id;
  }

  // Navigation methods
  goHome() {
    this.router.navigate(['/dashboard']);
  }

  goToCourse() {
    if (this.course) {
      this.router.navigate(['/course', this.course.id]);
    }
  }

  // Header-related methods
  toggleUserMenu() {
    this.showUserMenu = !this.showUserMenu;
  }

  onCourseSelected(course: Course) {
    this.router.navigate(['/course', course.id]);
  }

  onSearchResults(results: Course[]) {
    // Handle search results if needed
  }

  navigateToProfile() {
    this.showUserMenu = false;
    this.router.navigate(['/profile']);
  }

  navigateToAdminConsole() {
    this.showUserMenu = false;
    this.router.navigate(['/admin']);
  }

  navigateToMyCourses() {
    this.showUserMenu = false;
    this.router.navigate(['/my-courses']);
  }

  navigateToBlog() {
    this.showUserMenu = false;
    this.router.navigate(['/blog']);
  }

  logout() {
    this.showUserMenu = false;
    this.router.navigate(['/login']);
  }

  onVideoLoaded() {
    this.videoLoaded = true;
  }

  onVideoError(event: any) {
    console.error('Video failed to load:', event);
  }
}
