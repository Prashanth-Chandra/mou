import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { Course } from '../../models/course.model';

@Component({
  selector: 'app-author-dashboard',
  template: `
    <div class="author-dashboard-container">
      <nav class="breadcrumb">
        <span (click)="goHome()">Home</span> &gt; <span>My Courses</span>
      </nav>
      <div class="dashboard-header">
        <h1>My Courses</h1>
        <button class="create-btn" (click)="createNewCourse()">Create New</button>
      </div>
      <div class="dashboard-controls">
        <div class="tabs">
          <button *ngFor="let tab of tabs" [class.active]="activeTab === tab" (click)="setTab(tab)">{{tab}}</button>
        </div>
        <input type="text" placeholder="Search course" [(ngModel)]="searchTerm" />
        <select [(ngModel)]="sortOption">
          <option *ngFor="let opt of sortOptions" [value]="opt">{{opt}}</option>
        </select>
      </div>
      <div class="course-grid">
        <!-- Reuse Course Card Component -->
        <app-course-card *ngFor="let course of filteredCourses()" [course]="course" (click)="openCourse(course)"></app-course-card>
      </div>
    </div>
  `,
  styles: [`
    .author-dashboard-container { max-width: 1200px; margin: 0 auto; padding: 32px; }
    .dashboard-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
    .create-btn { background: #2563eb; color: #fff; border: none; padding: 10px 24px; border-radius: 6px; font-weight: 600; cursor: pointer; }
    .dashboard-controls { display: flex; gap: 16px; align-items: center; margin-bottom: 24px; }
    .tabs { display: flex; gap: 8px; }
    .tabs button { background: none; border: none; padding: 8px 16px; border-bottom: 2px solid transparent; cursor: pointer; font-weight: 500; }
    .tabs button.active { border-bottom: 2px solid #2563eb; color: #2563eb; }
    .course-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 24px; }
  `]
})
export class AuthorDashboardComponent implements OnInit {
  tabs = ['Published', 'Draft', 'Archived'];
  activeTab = 'Published';
  searchTerm = '';
  sortOption = 'Latest';
  sortOptions = ['Latest', 'Highest Rating', 'Highest Reviewed', 'A-Z', 'Z-A'];
  courses: Course[] = [];

  constructor(private router: Router, private authService: AuthService) {}

  ngOnInit() {
    // TODO: Load courses for the current author
  }

  setTab(tab: string) { this.activeTab = tab; }
  goHome() { this.router.navigate(['/dashboard']); }
  createNewCourse() { this.router.navigate(['/create-course']); }
  openCourse(course: Course) { this.router.navigate(['/course', course.id, 'edit']); }
  filteredCourses() {
    // TODO: Filter by tab, search, and sort
    return this.courses;
  }
}
