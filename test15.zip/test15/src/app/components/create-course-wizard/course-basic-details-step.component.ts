import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-course-basic-details-step',
  template: `
    <div class="basic-details-step">
      <h2>Details</h2>
      <label>Course Title</label>
      <input type="text" placeholder="Enter Course title here" [(ngModel)]="title" />
      <label>Description</label>
      <textarea placeholder="Enter Course title here" [(ngModel)]="description"></textarea>
      <label>Upload Course thumbnail</label>
      <app-file-uploader (fileSelected)="onFileSelected($event)"></app-file-uploader>
      <div class="actions">
        <button (click)="next()">Next</button>
      </div>
    </div>
  `,
  styles: [`
    .basic-details-step { background: #fff; padding: 32px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }
    label { display: block; margin-top: 16px; font-weight: 500; }
    input, textarea { width: 100%; margin-top: 8px; padding: 8px; border: 1px solid #d1d5db; border-radius: 6px; }
    .actions { margin-top: 24px; }
  `]
})
export class CourseBasicDetailsStepComponent {
  title = '';
  description = '';
  @Output() next = new EventEmitter<void>();
  onFileSelected(file: File) { /* TODO: handle file */ }
  next() { this.next.emit(); }
}
