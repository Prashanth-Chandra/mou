import { Component } from '@angular/core';

@Component({
  selector: 'app-create-course-wizard',
  template: `
    <div class="wizard-container">
      <nav class="breadcrumb">
        <span (click)="goHome()">Home</span> &gt; <span>My Courses</span> &gt; <span>Create New Course</span>
      </nav>
      <h1>Create New Course</h1>
      <div class="stepper">
        <div *ngFor="let step of steps; let i = index" [class.active]="currentStep === i">
          <span>{{i+1 | number:'2.0'}}</span> {{step}}
        </div>
      </div>
      <div class="wizard-step">
        <ng-container [ngSwitch]="currentStep">
          <app-course-basic-details-step *ngSwitchCase="0" (next)="nextStep($event)"></app-course-basic-details-step>
          <!-- TODO: Add other steps -->
        </ng-container>
      </div>
      <div class="wizard-actions">
        <button (click)="prevStep()" [disabled]="currentStep === 0">Prev</button>
        <button (click)="nextStep()" [disabled]="!canProceed()">Next</button>
        <button (click)="publish()" [disabled]="!canPublish()">Publish</button>
      </div>
    </div>
  `,
  styles: [`
    .wizard-container { max-width: 800px; margin: 0 auto; padding: 32px; }
    .stepper { display: flex; gap: 24px; margin-bottom: 32px; }
    .stepper div { padding: 8px 16px; border-radius: 20px; background: #f3f4f6; color: #374151; }
    .stepper div.active { background: #2563eb; color: #fff; font-weight: 600; }
    .wizard-actions { display: flex; gap: 16px; margin-top: 32px; }
  `]
})
export class CreateCourseWizardComponent {
  steps = ['Basic Details', 'Course Content', 'Overview'];
  currentStep = 0;

  goHome() {}
  nextStep($event?: any) { this.currentStep = Math.min(this.currentStep + 1, this.steps.length - 1); }
  prevStep() { this.currentStep = Math.max(this.currentStep - 1, 0); }
  canProceed() { return true; }
  canPublish() { return this.currentStep === this.steps.length - 1; }
  publish() { /* TODO: Publish logic */ }
}
