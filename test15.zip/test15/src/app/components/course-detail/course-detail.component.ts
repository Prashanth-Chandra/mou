import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { ActivatedRoute, Router } from '@angular/router';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { CourseService } from '../../services/course.service';
import { Course } from '../../models/course.model';
import { Enrollment, CourseProgress } from '../../models/enrollment.model';
import { User } from '../../models/user.model';

@Component({
  selector: 'app-course-detail',
  standalone: true,
  imports: [CommonModule],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ height: '0', opacity: '0' }),
        animate('200ms ease-in', style({ height: '*', opacity: '1' }))
      ]),
      transition(':leave', [
        animate('200ms ease-out', style({ height: '0', opacity: '0' }))
      ])
    ])
  ],
  template: `
    <div class="course-detail-container" *ngIf="course">
      <!-- Header -->
      <header class="course-header">
        <div class="header-content">
          <h1 class="product-name">Product Name</h1>
          <div class="search-wrapper">
            <svg class="search-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
              <circle cx="11" cy="11" r="8"></circle>
              <path d="m21 21-4.35-4.35"></path>
            </svg>
            <input 
              type="text" 
              class="search-input"
              placeholder="Search Courses"
            />
            <button class="clear-button" type="button">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <line x1="18" y1="6" x2="6" y2="18"></line>
                <line x1="6" y1="6" x2="18" y2="18"></line>
              </svg>
            </button>
          </div>
          <div class="header-actions">
            <div class="notification-icon">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"></path>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
              </svg>
              <span class="notification-badge">1</span>
            </div>
            <div class="user-menu" *ngIf="currentUser">
              <img [src]="currentUser.avatarUrl" [alt]="currentUser.fullName" class="user-avatar" (click)="toggleUserMenu()" />
              <div class="user-dropdown" [class.show]="showUserMenu">
                <div class="user-info">
                  <p class="user-name">{{ currentUser.fullName }}</p>
                  <p class="user-email">{{ currentUser.email }}</p>
                </div>
                <hr>
                <button class="dropdown-item">Profile</button>
                <button class="dropdown-item">Settings</button>
                <hr>
                <button class="dropdown-item logout" (click)="logout()">Logout</button>
              </div>
            </div>
          </div>
        </div>
      </header>

      <!-- Breadcrumb -->
      <div class="breadcrumb-container">
        <div class="breadcrumb-content">
          <a href="#" (click)="goToHome()" class="breadcrumb-link">Home</a>
          <span class="breadcrumb-separator">></span>
          <span class="breadcrumb-current">{{ course.title }}</span>
        </div>
      </div>

      <!-- Course Hero Section -->
      <div class="course-hero">
        <div class="hero-content">
          <div class="course-info">
            <h1 class="course-title" style="font-size: 48px; font-weight: bold;">{{ course.title }}</h1>

            <p class="course-subtitle">{{ course.subtitle }}</p>
            
            <div class="author-info">
              <span class="created-by">Created by: </span>
              <a href="#" class="author-link">{{ getAuthorName() }}</a>
            </div>

            <div class="action-buttons">
              <button 
                class="enroll-button" 
                *ngIf="!isEnrolled"
                (click)="enrollInCourse()"
                [disabled]="isEnrolling">
                {{ isEnrolling ? 'Enrolling...' : 'Enroll Now' }}
              </button>
              <button 
                class="learn-button" 
                *ngIf="isEnrolled"
                (click)="startLearning()">
                {{ courseProgress?.completionPercentage ? 'Continue Learning' : 'Start Learning' }}
              </button>
              <div class="enrollment-status" *ngIf="isEnrolled && courseProgress">
                <div class="progress-info">
                  <span class="progress-text">{{ courseProgress.completionPercentage }}% Complete</span>
                  <div class="progress-bar">
                    <div class="progress-fill" [style.width.%]="courseProgress.completionPercentage"></div>
                  </div>
                </div>
              </div>
            </div>
            
            <div class="enrollment-info">
              <span class="enrollment-count">{{ formatNumber(course.enrollmentCount) }} already enrolled</span>
            </div>
          </div>
          
          <div class="course-visual">
            <div class="decorative-circles">
              <div class="circle circle-1"></div>
              <div class="circle circle-2"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Course Meta Info -->
      <div class="course-meta-section">
        <div class="meta-content">
          <div class="meta-item">
            <span class="meta-label">Level</span>
            <span class="meta-value">{{ course.difficulty }} Level</span>
          </div>
          <div class="meta-item">
            <span class="meta-label">Rating</span>
            <div class="rating-info">
              <span class="rating-value">{{ course.rating }}</span>
              <svg class="star" width="16" height="16" viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
              <span class="review-count">({{ formatNumber(course.reviewCount) }} reviews)</span>
            </div>
          </div>
          <div class="meta-item">
            <span class="meta-label">Duration</span>
            <span class="meta-value">{{ course.durationText }}</span>
          </div>
          <div class="meta-item">
            <span class="meta-label">Flexible Schedule</span>
            <span class="meta-value">Learn at your own pace</span>
          </div>
        </div>
      </div>

      <!-- Course Content Tabs -->
      <div class="course-content-section">
        <div class="content-wrapper">
          <div class="tab-navigation">
            <button 
              class="tab-button"
              [class.active]="activeTab === 'overview'"
              (click)="setActiveTab('overview')"
            >
              Overview
            </button>
            <button 
              class="tab-button"
              [class.active]="activeTab === 'content'"
              (click)="setActiveTab('content')"
            >
              Course Content
            </button>
            <button 
              class="tab-button"
              [class.active]="activeTab === 'author'"
              (click)="setActiveTab('author')"
            >
              Author Details
            </button>
            <button 
              class="tab-button"
              [class.active]="activeTab === 'testimonials'"
              (click)="setActiveTab('testimonials')"
            >
              Testimonials
            </button>
          </div>

          <div class="tab-content">
            <!-- Overview Tab -->
            <div *ngIf="activeTab === 'overview'" class="tab-panel">
              <div class="overview-content">
                <section class="what-youll-learn">
                  <h3>What you'll Learn</h3>
                  <ul class="learning-objectives">
                    <li *ngFor="let objective of course.whatYoullLearn">{{ objective }}</li>
                  </ul>
                </section>

                <section class="skills-section">
                  <h3>Skills you'll gain</h3>
                  <div class="skills-tags">
                    <span *ngFor="let skill of course.skills" class="skill-tag">{{ skill }}</span>
                  </div>
                </section>

                <section class="requirements-section">
                  <h3>Requirements</h3>
                  <ul class="requirements-list">
                    <li *ngFor="let requirement of course.requirements">{{ requirement }}</li>
                  </ul>
                </section>

                <section class="description-section">
                  <h3>Description</h3>
                  <p class="course-description">{{ getCourseDescription() }}</p>
                </section>
              </div>
            </div>

            <!-- Course Content Tab -->
            <div *ngIf="activeTab === 'content'" class="tab-panel">
              <div class="course-content">
                
                <!-- Course Overview Statistics -->
                <div class="course-stats-header" *ngIf="curriculum && curriculum.length > 0">
                  <div class="stats-info">
                    <span class="stats-text">{{ getTotalSections() }} Sections • {{ getTotalLectures() }} Lectures • {{ formatDuration(getTotalDurationMinutes()) }} total length</span>
                  </div>
                  <div class="expand-all">
                    <button class="expand-button" (click)="toggleAllSections()">
                      <svg class="expand-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                        <polyline points="6,9 12,15 18,9"></polyline>
                      </svg>
                      {{ allExpanded ? 'Collapse all sections' : 'Expand all sections' }}
                    </button>
                  </div>
                </div>

                <!-- Curriculum Sections -->
                <div class="curriculum-sections">
                  <div class="curriculum-section" *ngFor="let section of curriculum; let i = index; trackBy: trackBySection">
                    <div class="section-header" (click)="toggleSection(i)">
                      <div class="section-toggle">
                        <svg class="toggle-icon" [class.expanded]="section.expanded" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                          <polyline points="9,18 15,12 9,6"></polyline>
                        </svg>
                        <h4 class="section-title">{{ section.title }}</h4>
                      </div>
                      <div class="section-meta">
                        <span class="section-stats">{{ getSectionLectureCount(section) }} lectures • {{ formatDuration(getSectionDuration(section)) }}</span>
                      </div>
                    </div>
                    
                    <div class="lecture-list" *ngIf="section.expanded">
                      <div class="lecture-item" *ngFor="let lecture of section.lectures; trackBy: trackByLecture">
                        <div class="lecture-content">
                          <div class="lecture-icon">
                            <svg *ngIf="lecture.type === 'Video'" width="16" height="16" viewBox="0 0 24 24" fill="none">
                              <rect x="2" y="3" width="20" height="14" rx="2" ry="2" stroke="currentColor" stroke-width="2"/>
                              <polygon points="10,8 16,12 10,16" fill="currentColor"/>
                            </svg>
                            <svg *ngIf="lecture.type === 'Text'" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                              <polyline points="14,2 14,8 20,8"></polyline>
                            </svg>
                            <svg *ngIf="lecture.type === 'PDF'" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                              <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                              <polyline points="14,2 14,8 20,8"></polyline>
                            </svg>
                          </div>
                          <span class="lecture-title">{{ lecture.title }}</span>
                          <span class="lecture-duration" *ngIf="lecture.durationMinutes">{{ formatDuration(lecture.durationMinutes) }}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div *ngIf="!curriculum || curriculum.length === 0" class="no-curriculum">
                  <p>Curriculum information is not available for this course.</p>
                </div>
              </div>
            </div>

            <!-- Author Details Tab -->
            <div *ngIf="activeTab === 'author'" class="tab-panel">
              <div class="author-content">
                <h3>About the Instructor</h3>
                <p>{{ getAuthorName() }} - Expert in the field with years of experience.</p>
              </div>
            </div>

            <!-- Testimonials Tab -->
            <div *ngIf="activeTab === 'testimonials'" class="tab-panel">
              <div class="testimonials-content">
                <h3>Student Reviews</h3>
                <div class="reviews-container" *ngIf="getReviews().length > 0">
                  <div class="review-item" *ngFor="let review of getReviews()">
                    <div class="review-header">
                      <div class="reviewer-info">
                        <h4 class="reviewer-name">{{ getUserName(review.userId) }}</h4>
                        <div class="review-rating">
                          <span *ngFor="let star of getStarArray(review.rating)" class="star-icon">
                            <svg width="16" height="16" viewBox="0 0 24 24" [class.filled]="star">
                              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                            </svg>
                          </span>
                          <span class="rating-number">{{ review.rating }}/5</span>
                        </div>
                      </div>
                    </div>
                    <div class="review-content">
                      <p>"{{ review.comment }}"</p>
                    </div>
                  </div>
                </div>
                <div *ngIf="getReviews().length === 0" class="no-reviews">
                  <p>No reviews available for this course yet.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Related Courses Section -->
      <div class="related-courses-section" *ngIf="course">
        <div class="related-courses-container">
          <h3 class="related-courses-title">Related Courses</h3>
          <div class="related-courses-list" *ngIf="relatedCourses && relatedCourses.length > 0">
            <div class="related-course-item" *ngFor="let relatedCourse of relatedCourses; trackBy: trackByRelatedCourse" (click)="navigateToRelatedCourse(relatedCourse.id.toString())">
              <div class="course-icon">
                <img [src]="relatedCourse.thumbnailUrl" [alt]="relatedCourse.title" />
              </div>
              <div class="course-info">
                <h4 class="course-title">{{ relatedCourse.title }}</h4>
                <div class="course-meta">
                  <span class="course-duration">{{ relatedCourse.durationText }}</span>
                  <span class="course-separator">|</span>
                  <span class="course-update">Last updated {{ getFormattedDate(relatedCourse.publishedDate) }}</span>
                </div>
              </div>
              <div class="course-rating-section">
                <div class="rating-score">{{ relatedCourse.rating }}</div>
                <div class="rating-reviews">({{ formatNumber(relatedCourse.reviewCount) }} reviews)</div>
                <div class="course-badge" *ngIf="getCourseBadge(relatedCourse)">
                  {{ getCourseBadge(relatedCourse) }}
                </div>
              </div>
            </div>
          </div>
          <div *ngIf="!relatedCourses || relatedCourses.length === 0" class="no-related-courses">
            <p>No related courses available at the moment.</p>
          </div>
        </div>
      </div>
    </div>

    <div *ngIf="!course" class="loading">
      <p>Loading course details...</p>
    </div>
  `,
  styles: [`
    .course-detail-container {
      min-height: 100vh;
      background: #f8fafc;
    }

    /* Header Styles */
    .course-header {
      background: white;
      border-bottom: 1px solid #e5e7eb;
      padding: 0 24px;
    }

    .header-content {
      display: flex;
      align-items: center;
      justify-content: space-between;
      height: 64px;
      max-width: 1400px;
      margin: 0 auto;
    }

    .product-name {
      font-size: 20px;
      font-weight: 600;
      color: #111827;
      margin: 0;
      cursor: pointer;
    }

    .search-wrapper {
      position: relative;
      display: flex;
      align-items: center;
      background: white;
      border: 2px solid #e5e7eb;
      border-radius: 8px;
      padding: 0 12px;
      max-width: 600px;
      flex: 1;
      margin: 0 24px;
    }

    .search-icon {
      color: #9ca3af;
      margin-right: 8px;
    }

    .search-input {
      flex: 1;
      border: none;
      outline: none;
      padding: 12px 0;
      font-size: 14px;
      background: transparent;
    }

    .clear-button {
      background: none;
      border: none;
      color: #9ca3af;
      cursor: pointer;
      padding: 4px;
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .notification-icon {
      position: relative;
      cursor: pointer;
      color: #6b7280;
    }

    .notification-badge {
      position: absolute;
      top: -4px;
      right: -4px;
      background: #ef4444;
      color: white;
      border-radius: 50%;
      width: 16px;
      height: 16px;
      font-size: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .user-avatar {
      width: 32px;
      height: 32px;
      border-radius: 50%;
      overflow: hidden;
      cursor: pointer;
      background: #e5e7eb;
    }

    .user-avatar img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    /* Breadcrumb */
    .breadcrumb-container {
      background: #f8fafc;
      padding: 16px 24px;
      border-bottom: 1px solid #e5e7eb;
    }

    .breadcrumb-content {
      max-width: 1400px;
      margin: 0 auto;
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .breadcrumb-link {
      color: #0066cc;
      text-decoration: none;
      font-size: 14px;
    }

    .breadcrumb-separator {
      color: #6b7280;
      font-size: 14px;
    }

    .breadcrumb-current {
      color: #111827;
      font-size: 14px;
      font-weight: 500;
    }

    /* Course Hero */
    .course-hero {
      background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
      padding: 48px 24px;
      position: relative;
      overflow: hidden;
    }

    .hero-content {
      max-width: 1400px;
      margin: 0 auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .course-info {
      flex: 1;
      max-width: 600px;
    }

    .course-title {
      font-size: 80px;
      font-weight: 700;
      color: #111827;
      margin: 0 0 16px 0;
      line-height: 1.2;
    }

    .course-subtitle {
      font-size: 18px;
      color: #6b7280;
      margin: 0 0 24px 0;
      line-height: 1.5;
    }

    .author-info {
      margin-bottom: 32px;
      font-size: 14px;
    }

    .created-by {
      color: #6b7280;
    }

    .author-link {
      color: #0066cc;
      text-decoration: none;
      font-weight: 500;
    }

    .action-buttons {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-bottom: 16px;
    }

    .enroll-button {
      background: #0066cc;
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .enroll-button:hover:not(:disabled) {
      background: #0052a3;
    }

    .enroll-button:disabled {
      background: #9ca3af;
      cursor: not-allowed;
    }

    .learn-button {
      background: #10b981;
      color: white;
      border: none;
      padding: 12px 24px;
      border-radius: 6px;
      font-size: 16px;
      font-weight: 600;
      cursor: pointer;
      transition: background 0.2s ease;
    }

    .learn-button:hover:not(:disabled) {
      background: #059669;
    }

    .enrollment-status {
      margin-top: 8px;
    }

    .progress-info {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .progress-text {
      font-size: 14px;
      color: #6b7280;
      font-weight: 500;
    }

    .progress-bar {
      width: 100%;
      height: 6px;
      background: #e5e7eb;
      border-radius: 3px;
      overflow: hidden;
    }

    .progress-fill {
      height: 100%;
      background: #10b981;
      transition: width 0.3s ease;
    }

    .enrollment-info {
      font-size: 14px;
      color: #6b7280;
    }

    .course-visual {
      position: relative;
      flex: 1;
      height: 300px;
    }

    .decorative-circles {
      position: relative;
      width: 100%;
      height: 100%;
    }

    .circle {
      position: absolute;
      border: 2px solid #0066cc;
      border-radius: 50%;
      opacity: 0.3;
    }

    .circle-1 {
      width: 200px;
      height: 200px;
      top: 20px;
      right: 100px;
    }

    .circle-2 {
      width: 150px;
      height: 150px;
      bottom: 20px;
      right: 50px;
    }

    /* Course Meta */
    .course-meta-section {
      background: white;
      padding: 24px;
      border-bottom: 1px solid #e5e7eb;
    }

    .meta-content {
      max-width: 1400px;
      margin: 0 auto;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 24px;
    }

    .meta-item {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .meta-label {
      font-size: 12px;
      color: #6b7280;
      font-weight: 500;
    }

    .meta-value {
      font-size: 14px;
      color: #111827;
      font-weight: 600;
    }

    .rating-info {
      display: flex;
      align-items: center;
      gap: 4px;
    }

    .rating-value {
      font-size: 14px;
      color: #111827;
      font-weight: 600;
    }

    .star {
      fill: #fbbf24;
      stroke: none;
    }

    .review-count {
      font-size: 12px;
      color: #6b7280;
    }

    /* Course Content */
    .course-content-section {
      background: white;
      min-height: 600px;
    }

    .content-wrapper {
      max-width: 1400px;
      margin: 0 auto;
      padding: 24px;
    }

    .tab-navigation {
      display: flex;
      border-bottom: 1px solid #e5e7eb;
      margin-bottom: 32px;
    }

    .tab-button {
      background: none;
      border: none;
      padding: 12px 24px;
      font-size: 14px;
      color: #6b7280;
      cursor: pointer;
      border-bottom: 2px solid transparent;
      transition: all 0.2s ease;
    }

    .tab-button.active {
      color: #0066cc;
      border-bottom-color: #0066cc;
    }

    .tab-button:hover {
      color: #0066cc;
    }

    .tab-content {
      min-height: 400px;
    }

    .overview-content section {
      margin-bottom: 32px;
    }

    .overview-content h3 {
      font-size: 18px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 16px 0;
    }

    .learning-objectives,
    .requirements-list {
      list-style: none;
      padding: 0;
      margin: 0;
    }

    .learning-objectives li,
    .requirements-list li {
      padding: 8px 0;
      color: #4b5563;
      position: relative;
      padding-left: 20px;
    }

    .learning-objectives li:before,
    .requirements-list li:before {
      content: "•";
      color: #0066cc;
      position: absolute;
      left: 0;
      font-weight: bold;
    }

    .skills-tags {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
    }

    .skill-tag {
      background: #e0f2fe;
      color: #0369a1;
      padding: 6px 12px;
      border-radius: 16px;
      font-size: 12px;
      font-weight: 500;
    }

    .course-description {
      color: #4b5563;
      line-height: 1.6;
      margin: 0;
    }

    /* Course Overview Statistics */
    .course-stats-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 0;
      border-bottom: 1px solid #e5e7eb;
      margin-bottom: 0;
    }

    .stats-info {
      flex: 1;
    }

    .stats-text {
      font-size: 14px;
      color: #374151;
      font-weight: 500;
    }

    .expand-all {
      flex-shrink: 0;
    }

    .expand-button {
      display: flex;
      align-items: center;
      gap: 8px;
      background: none;
      border: none;
      color: #0066cc;
      font-size: 14px;
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 4px;
      transition: background-color 0.2s ease;
    }

    .expand-button:hover {
      background-color: #f3f4f6;
    }

    .expand-icon {
      transition: transform 0.2s ease;
    }

    /* Curriculum Sections */
    .curriculum-sections {
      margin-top: 0;
    }

    .curriculum-section {
      border-bottom: 1px solid #e5e7eb;
    }

    .curriculum-section:last-child {
      border-bottom: none;
    }

    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 16px 0;
      cursor: pointer;
      transition: background-color 0.2s ease;
    }

    .section-header:hover {
      background-color: #f9fafb;
    }

    .section-toggle {
      display: flex;
      align-items: center;
      gap: 12px;
      flex: 1;
    }

    .toggle-icon {
      transition: transform 0.2s ease;
      color: #6b7280;
    }

    .toggle-icon.expanded {
      transform: rotate(90deg);
    }

    .section-title {
      font-size: 16px;
      font-weight: 600;
      color: #111827;
      margin: 0;
    }

    .section-meta {
      flex-shrink: 0;
    }

    .section-stats {
      font-size: 14px;
      color: #6b7280;
      font-weight: 400;
    }

    /* Lecture List */
    .lecture-list {
      background-color: #f9fafb;
      border-top: 1px solid #e5e7eb;
      overflow: hidden;
    }

    .lecture-item {
      border-bottom: 1px solid #e5e7eb;
    }

    .lecture-item:last-child {
      border-bottom: none;
    }

    .lecture-content {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 12px 32px;
      transition: background-color 0.2s ease;
    }

    .lecture-content:hover {
      background-color: #f3f4f6;
    }

    .lecture-icon {
      flex-shrink: 0;
      color: #6b7280;
      width: 16px;
      height: 16px;
    }

    .lecture-title {
      flex: 1;
      font-size: 14px;
      color: #374151;
      font-weight: 400;
    }

    .lecture-duration {
      flex-shrink: 0;
      font-size: 13px;
      color: #9ca3af;
      font-weight: 400;
    }

    .no-curriculum {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    .loading {
      display: flex;
      justify-content: center;
      align-items: center;
      height: 50vh;
      color: #6b7280;
    }

    .reviews-container {
      max-height: 600px;
      overflow-y: auto;
    }

    .review-item {
      background: #f8fafc;
      padding: 20px;
      border-radius: 8px;
      margin-bottom: 16px;
      border: 1px solid #e5e7eb;
    }

    .review-header {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 12px;
    }

    .reviewer-info h4 {
      margin: 0 0 8px 0;
      font-size: 16px;
      font-weight: 600;
      color: #111827;
    }

    .review-rating {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .star-icon {
      display: inline-flex;
    }

    .star-icon svg {
      fill: #d1d5db;
      stroke: none;
    }

    .star-icon svg.filled {
      fill: #fbbf24;
    }

    .rating-number {
      font-size: 14px;
      color: #6b7280;
      font-weight: 500;
    }

    .review-content p {
      margin: 0;
      color: #4b5563;
      font-style: italic;
      line-height: 1.6;
    }

    .no-reviews {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    /* Related Courses Section */
    .related-courses-section {
      background: white;
      border-top: 1px solid #e5e7eb;
      padding: 40px 0;
    }

    .related-courses-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 0 24px;
    }

    .related-courses-title {
      font-size: 18px;
      font-weight: 600;
      color: #111827;
      margin: 0 0 24px 0;
    }

    .related-courses-list {
      display: flex;
      flex-direction: column;
      gap: 0;
    }

    .related-course-item {
      display: flex;
      align-items: center;
      padding: 20px 0;
      border-bottom: 1px solid #e5e7eb;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .related-course-item:hover {
      background-color: #f9fafb;
      transform: translateX(4px);
      padding-left: 8px;
      margin-left: -8px;
      border-radius: 8px;
    }

    .related-course-item:hover .course-title {
      color: #0066cc;
    }

    .related-course-item:hover .course-icon {
      transform: scale(1.05);
    }

    .related-course-item:last-child {
      border-bottom: none;
    }

    .course-icon {
      width: 64px;
      height: 64px;
      flex-shrink: 0;
      margin-right: 16px;
      border-radius: 8px;
      overflow: hidden;
      background: #f3f4f6;
      transition: transform 0.2s ease;
    }

    .course-icon img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .course-info {
      flex: 1;
      min-width: 0;
    }

    .course-title {
      font-size: 16px;
      font-weight: 500;
      color: #111827;
      margin: 0 0 4px 0;
      line-height: 1.4;
      transition: color 0.2s ease;
    }

    .course-meta {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      color: #6b7280;
    }

    .course-duration {
      color: #6b7280;
    }

    .course-separator {
      color: #d1d5db;
    }

    .course-update {
      color: #6b7280;
    }

    .course-rating-section {
      display: flex;
      flex-direction: column;
      align-items: flex-end;
      gap: 4px;
      margin-left: 16px;
    }

    .rating-score {
      font-size: 14px;
      font-weight: 700;
      color: #1f2937;
      background: #fbbf24;
      color: white;
      padding: 4px 8px;
      border-radius: 4px;
      min-width: 32px;
      text-align: center;
    }

    .rating-reviews {
      font-size: 12px;
      color: #6b7280;
      white-space: nowrap;
    }

    .course-badge {
      background: #0066cc;
      color: white;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 10px;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      white-space: nowrap;
    }

    .course-badge:empty {
      display: none;
    }

    .no-related-courses {
      text-align: center;
      padding: 40px 20px;
      color: #6b7280;
    }

    @media (max-width: 768px) {
      .hero-content {
        flex-direction: column;
        text-align: center;
        gap: 32px;
      }

      .course-title {
        font-size: 32px;
      }

      .meta-content {
        grid-template-columns: repeat(2, 1fr);
      }

      .course-stats-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 12px;
      }

      .expand-all {
        align-self: flex-end;
      }

      .section-header {
        padding: 12px 0;
      }

      .section-toggle {
        gap: 8px;
      }

      .lecture-content {
        padding: 10px 24px;
      }

      .related-courses-list {
        gap: 0;
      }

      .related-course-item {
        padding: 16px 0;
      }

      .course-icon {
        width: 56px;
        height: 56px;
        margin-right: 12px;
      }

      .course-title {
        font-size: 15px;
      }

      .course-meta {
        font-size: 12px;
      }

      .course-rating-section {
        margin-left: 12px;
      }

      .rating-score {
        font-size: 13px;
        min-width: 28px;
        padding: 3px 6px;
      }

      .rating-reviews {
        font-size: 11px;
      }

      .course-badge {
        font-size: 9px;
        padding: 3px 6px;
      }

      .related-courses-container {
        padding: 0 16px;
      }

      .related-courses-title {
        font-size: 20px;
      }

      .tab-navigation {
        overflow-x: auto;
      }

      .tab-button {
        white-space: nowrap;
      }
    }
  `]
})
export class CourseDetailComponent implements OnInit {
  currentUser: User | null = null;
  showUserMenu = false;
  course: Course | null = null;
  activeTab: string = 'overview';
  curriculum: any[] = [];
  reviews: any[] = [];
  users: any[] = [];
  relatedCourses: Course[] = [];
  allExpanded: boolean = false;
  isEnrolled: boolean = false;
  isEnrolling: boolean = false;
  courseProgress: CourseProgress | null = null;
  currentUserId: string = '1'; // Hardcoded for demo - should come from auth service

  constructor(
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private courseService: CourseService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit() {
    // Subscribe to route parameter changes to handle navigation between courses
    this.route.paramMap.subscribe(params => {
      const courseId = params.get('id');
      if (courseId) {
        this.loadCourse(parseInt(courseId));
      }
    });
  }

  loadCourse(courseId: number) {
    this.courseService.getCourseById(courseId).subscribe({
      next: (course) => {
        this.course = course;
        // Check enrollment status
        this.checkEnrollmentStatus(courseId.toString());
        // Load curriculum data for this course
        this.loadCurriculum(courseId.toString());
        // Load reviews data for this course
        this.loadReviews(courseId.toString());
        // Load related courses
        this.loadRelatedCourses(courseId);
      },
      error: (error) => {
        console.error('Error loading course:', error);
        this.router.navigate(['/search']);
      }
    });
  }

  checkEnrollmentStatus(courseId: string) {
    this.courseService.isUserEnrolled(this.currentUserId, courseId).subscribe({
      next: (enrolled) => {
        this.isEnrolled = enrolled;
        if (enrolled) {
          this.loadCourseProgress(courseId);
        }
      },
      error: (error) => {
        console.error('Error checking enrollment status:', error);
        this.isEnrolled = false;
      }
    });
  }

  loadCourseProgress(courseId: string) {
    this.courseService.getCourseProgress(this.currentUserId, courseId).subscribe({
      next: (progress) => {
        this.courseProgress = progress;
      },
      error: (error) => {
        console.error('Error loading course progress:', error);
      }
    });
  }

  loadCurriculum(courseId: string) {
    this.courseService.getCourseCurriculum(courseId).subscribe({
      next: (curriculum) => {
        console.log('Loading curriculum:', curriculum);
        // Initialize expanded state for each section (first section expanded by default)
        this.curriculum = curriculum.map((section, index) => ({
          ...section,
          expanded: index === 0 // Only first section expanded by default
        }));
        console.log('Curriculum with expanded state:', this.curriculum);
        // Trigger change detection
        this.cdr.detectChanges();
      },
      error: (error) => {
        console.error('Error loading curriculum:', error);
        // If curriculum fails to load, keep empty array
        this.curriculum = [];
      }
    });
  }

  loadReviews(courseId: string) {
    this.courseService.getCourseReviews(courseId).subscribe({
      next: (reviews) => {
        this.reviews = reviews;
        // Load user details for each review
        this.loadUsersForReviews();
      },
      error: (error) => {
        console.error('Error loading reviews:', error);
        // If reviews fail to load, keep empty array
        this.reviews = [];
      }
    });
  }

  loadUsersForReviews() {
    const userIds = [...new Set(this.reviews.map(review => review.userId))];
    userIds.forEach(userId => {
      this.courseService.getUserById(userId).subscribe({
        next: (user) => {
          this.users.push(user);
        },
        error: (error) => {
          console.error('Error loading user:', error);
        }
      });
    });
  }

  loadRelatedCourses(currentCourseId: number) {
    this.courseService.getAllCourses().subscribe({
      next: (allCourses) => {
        // Filter out the current course and get a random selection of 5 related courses
        const otherCourses = allCourses.filter(course => Number(course.id) !== currentCourseId);
        
        // Sort by rating and select top courses, then shuffle for variety
        const sortedCourses = otherCourses.sort((a, b) => b.rating - a.rating);
        const shuffled = sortedCourses.sort(() => 0.5 - Math.random());
        
        this.relatedCourses = shuffled.slice(0, 5);
      },
      error: (error) => {
        console.error('Error loading related courses:', error);
        this.relatedCourses = [];
      }
    });
  }

  setActiveTab(tab: string) {
    this.activeTab = tab;
  }

  formatNumber(num: number): string {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  getAuthorName(): string {
    return this.course?.provider.name || 'Unknown Author';
  }

  getCourseDescription(): string {
    return `Master ${this.course?.title} with this comprehensive course. Learn the fundamentals and advanced techniques used by professionals in the field.`;
  }

  getCurriculum() {
    // Return curriculum from database if available, otherwise return empty array
    return this.curriculum || [];
  }

  getReviews() {
    // Return reviews from database if available, otherwise return empty array
    return this.reviews || [];
  }

  getUserName(userId: number): string {
    const user = this.users.find(u => u.id == userId);
    return user ? user.fullName : 'Anonymous User';
  }

  getStarArray(rating: number): boolean[] {
    return Array(5).fill(false).map((_, i) => i < Math.floor(rating));
  }

  // Course statistics methods
  getTotalSections(): number {
    return this.curriculum?.length || 0;
  }

  getTotalLectures(): number {
    return this.curriculum?.reduce((total, section) => total + (section.lectures?.length || 0), 0) || 0;
  }

  getTotalDurationMinutes(): number {
    return this.curriculum?.reduce((total, section) => {
      const sectionDuration = section.lectures?.reduce((sectionTotal: number, lecture: any) => {
        return sectionTotal + (lecture.durationMinutes || 0);
      }, 0) || 0;
      return total + sectionDuration;
    }, 0) || 0;
  }

  formatDuration(minutes: number): string {
    if (minutes === 0) return '0 min';
    
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    
    if (hours > 0) {
      return remainingMinutes > 0 ? `${hours}h ${remainingMinutes}m` : `${hours}h`;
    }
    return `${minutes}m`;
  }

  // Section statistics methods
  getSectionDuration(section: any): number {
    return section.lectures?.reduce((total: number, lecture: any) => {
      return total + (lecture.durationMinutes || 0);
    }, 0) || 0;
  }

  getSectionLectureCount(section: any): number {
    return section.lectures?.length || 0;
  }

  // Section toggle methods
  toggleSection(index: number) {
    if (this.curriculum[index]) {
      this.curriculum[index].expanded = !this.curriculum[index].expanded;
    }
  }

  toggleAllSections() {
    this.allExpanded = !this.allExpanded;
    this.curriculum.forEach(section => {
      section.expanded = this.allExpanded;
    });
  }

  // TrackBy functions for performance
  trackBySection(index: number, section: any): any {
    return section.id || index;
  }

  trackByLecture(index: number, lecture: any): any {
    return lecture.id || index;
  }

  trackByRelatedCourse(index: number, course: Course): any {
    return course.id || index;
  }

  // Related courses helper methods
  getCourseBadge(course: Course): string {
    if (course.rating >= 4.7) {
      return 'Highest Rated';
    } else if (course.enrollmentCount >= 50000) {
      return 'Bestseller';
    } else if (course.difficulty === 'Beginner') {
      return 'Beginner Friendly';
    } else if (course.difficulty === 'Advanced') {
      return 'Advanced';
    }
    return '';
  }

  getFormattedDate(dateString: string): string {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - date.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 30) {
      return `${diffDays} days ago`;
    } else if (diffDays < 365) {
      const months = Math.floor(diffDays / 30);
      return `${months} month${months > 1 ? 's' : ''} ago`;
    } else {
      const years = Math.floor(diffDays / 365);
      return `${years} year${years > 1 ? 's' : ''} ago`;
    }
  }

  navigateToRelatedCourse(courseId: string) {
    this.router.navigate(['/course', courseId]);
  }

  enrollInCourse() {
    if (this.course) {
      this.isEnrolling = true;
      this.courseService.enrollUserInCourse(this.currentUserId, this.course.id.toString()).subscribe({
        next: (enrollment) => {
          this.isEnrolled = true;
          this.isEnrolling = false;
          console.log('Successfully enrolled in course:', enrollment);
          // Load course progress after enrollment
          this.loadCourseProgress(this.course!.id.toString());
        },
        error: (error) => {
          console.error('Error enrolling in course:', error);
          this.isEnrolling = false;
        }
      });
    }
  }

  startLearning() {
    if (this.course) {
      this.router.navigate(['/learn', this.course.id]);
    }
  }

  toggleUserMenu(): void {
    this.showUserMenu = !this.showUserMenu;
  }

  goToDashboard() {
    this.router.navigate(['/dashboard']);
  }

  goToHome() {
    this.router.navigate(['/dashboard']);
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

}
